CREATE TABLE ACCOUNT (
  ACCOUNT_ID                int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ALTERNATE_NUMBER  varchar(17)     NOT NULL,
  ACCOUNT_NAME              varchar(100)    DEFAULT NULL,
  ACCOUNT_TYPE              varchar(100)    NOT NULL, -- check constraint and comment required
  EFFECTIVE_FROM            datetime        NOT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  REASON_FOR_CHANGE         varchar(250)    DEFAULT NULL,
  
  PRIMARY KEY (ACCOUNT_ID)
);


CREATE TABLE ACCOUNT_LIMIT (
  ACCOUNT_ID                int(11)         NOT NULL,
  EFFECTIVE_FROM            datetime        NOT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  ACCOUNT_LIMIT_AMOUNT      decimal(16,2)   DEFAULT NULL,
  REASON_FOR_CHANGE         varchar(30)     DEFAULT NULL,
  CREATED_DATE              datetime        NOT NULL,
  ACTION_TYPE               smallint(1)     DEFAULT NULL,   -- check constraint and comment, or preferably fk to reference data
  
  PRIMARY KEY (ACCOUNT_ID, EFFECTIVE_FROM),
  CONSTRAINT FK_A_C_LIMIT FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);


-- This table requires a synthetic key
CREATE TABLE ACCOUNT_STATUS (
  ACCOUNT_ID                int(11)         NOT NULL,
  ACCOUNT_STATUS_TYPE_ID    smallint(6)     NOT NULL,   -- check constraint and comment
  EFFECTIVE_FROM            datetime        NOT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  REASON_FOR_CHANGE         varchar(30)     DEFAULT NULL,
  
  PRIMARY KEY (ACCOUNT_ID, ACCOUNT_STATUS_TYPE_ID, EFFECTIVE_FROM),
  CONSTRAINT FK_A_C_STATUS FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);

-- this table requires a synthetic key
-- this table should be split into account owner/authorised account user
CREATE TABLE ACCOUNT_USER (
  ACCOUNT_ID                int(11)         NOT NULL,
  PARTY_EORI                varchar(17)     NOT NULL,
  ACCOUNT_PERMISSION_TYPE   varchar(100)    DEFAULT NULL,   -- check constraint and comment (See also table comment)
  EFFECTIVE_FROM            datetime        NOT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  VIEW_BALANCE              char(1)         NOT NULL, -- check constraint and comment, should be varchar rather than char
  
  PRIMARY KEY (ACCOUNT_ID, PARTY_EORI, EFFECTIVE_FROM),
  CONSTRAINT FK_A_C_PARTY FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);


-- should include type, effective_from/effective_to
CREATE TABLE ADDRESS (
  ADDRESS_ID                int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ID                int(11)         NOT NULL,
  ADDRESSLINE1              varchar(35)     NOT NULL,
  ADDRESSLINE2              varchar(35)     DEFAULT NULL,
  ADDRESSLINE3              varchar(35)     DEFAULT NULL,
  POSTCODE                  varchar(35)     DEFAULT NULL,
  COUNTRYCODE               varchar(2)      DEFAULT NULL,
  
  PRIMARY KEY (ADDRESS_ID),
  KEY FK_ADDRESS_ACCOUNT (ACCOUNT_ID),
  CONSTRAINT FK_ADDRESS_ACCOUNT FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);


CREATE TABLE AUTHORISATION (
  AUTHORISATION_ID          int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ID                int(11)         NOT NULL,
  AUTHORISATION_TYPE        varchar(10)     NOT NULL, -- check constraint & comment
  STATUS                    smallint(6)     DEFAULT NULL, -- check constraint & comment, if not fk to ref data
  WAIVER_PERCENTAGE         int(11)         DEFAULT NULL,
  EFFECTIVE_FROM            datetime        DEFAULT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  
  PRIMARY KEY (AUTHORISATION_ID),
  KEY FK_AUTHORISATION_ACCOUNT (ACCOUNT_ID),
  CONSTRAINT FK_AUTHORISATION_ACCOUNT FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);

CREATE TABLE GUARANTEE (
  GUARANTEE_ID              int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ID                int(11)         NOT NULL,
  GUARANTOR_ID              varchar(10)     NOT NULL,
  PERMANENT_GUARANTEE_INDICATOR char(1)     NOT NULL, -- check constraint and comment
  
  PRIMARY KEY (GUARANTEE_ID),
  KEY FK_A_C_GUARANTEE (ACCOUNT_ID),
  CONSTRAINT FK_A_C_GUARANTEE FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);

CREATE TABLE GUARANTEE_LIMIT (
  GUARANTEE_LIMIT_ID        int(11)         NOT NULL AUTO_INCREMENT,
  GUARANTEE_ID              int(11)         NOT NULL,
  EFFECTIVE_FROM            datetime        NOT NULL,
  EFFECTIVE_TO              datetime        DEFAULT NULL,
  GUARANTEE_LIMIT           decimal(16,2)   DEFAULT NULL,
  GUARANTEE_REFERENCE_NUMBER varchar(40)    DEFAULT NULL,
  GUARANTEE_INTERNAL_REFERENCE varchar(12)  NOT NULL,
  REASON_FOR_CHANGE         varchar(30)     DEFAULT NULL,
  
  PRIMARY KEY (GUARANTEE_LIMIT_ID),
  UNIQUE KEY UC_GUARANTEE_INTERNAL_REFERENCE (GUARANTEE_INTERNAL_REFERENCE),
  KEY FK_GUARANTEE_LIMIT (GUARANTEE_ID),
  CONSTRAINT FK_GUARANTEE_LIMIT FOREIGN KEY (GUARANTEE_ID) REFERENCES GUARANTEE (GUARANTEE_ID)
);

CREATE TABLE INTERIM_PAYMENT_HISTORY (
  INTERIM_PAYMENT_HISTORY_ID    int(11)         NOT NULL AUTO_INCREMENT,
  DAN                           varchar(17)     NOT NULL, -- seems overly specific, cash account? guarantee account?
  INTERIM_PAYMENT_ENTRY_TYPE    varchar(50)     NOT NULL, -- check constraint & comment
  INTERIM_PAYMENT_ENTRY_AMOUNT  decimal(16,2)   NOT NULL,
  CHARGE_DATE                   datetime        NOT NULL,
  CREATION_DATE                 timestamp       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (INTERIM_PAYMENT_HISTORY_ID)
);


CREATE TABLE MESSAGING (
  MSG_ID                    bigint(20)      NOT NULL AUTO_INCREMENT COMMENT 'A system-generated surrogate key to uniquely identify the messaging record.',
  RECEIVED_MSG_ID           varchar(50)     NOT NULL COMMENT 'The ID of the message received from CHIEF.',
  DAN                       int(11)         DEFAULT NULL, -- seems overly specific, cash account? guarantee account?
  RECEIVED_MSG_TYPE         varchar(30)     NOT NULL COMMENT 'The type of message received from CHIEF. Currently, this would be Correlation_ID or SYS-MRN_ID, but could include other message types in future.', -- probably fk to ref data, comment needs include values
  CREATED_DATE              timestamp       NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'The system date/ time this record was created in this table.',
  
  PRIMARY KEY (MSG_ID),
  KEY AK_Key_2 (RECEIVED_MSG_ID,RECEIVED_MSG_TYPE),
  KEY INDEX_1 (MSG_ID)
) COMMENT='Restricts the duplicate entries going into the posting';


CREATE TABLE POSTING (
  POSTING_ID                int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ID                int(11)         NOT NULL,
  DAN                       varchar(17)     NOT NULL, -- seems overly specific, cash account? guarantee account?
  REFERENCE_ID              varchar(35)     DEFAULT NULL,
  POSTING_TYPE              varchar(100)    NOT NULL,  -- check constraint & comment or fk to ref data
  GUARANTEE_CHARGE          decimal(16,2)   NOT NULL,
  ACCOUNT_CHARGE            decimal(16,2)   NOT NULL,
  CHARGE_DATE               datetime        NOT NULL,
  BANK_TRANSACTION_REFERENCE varchar(16)    DEFAULT NULL,
  CREATION_DATE             timestamp       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (POSTING_ID),
  KEY FK_A_C_POSTING (ACCOUNT_ID),
  CONSTRAINT FK_A_C_POSTING FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);


CREATE TABLE RESERVATION (
  RESERVATION_ID                int(11)         NOT NULL AUTO_INCREMENT,
  DECLARATION_ID                varchar(35)     NOT NULL,
  ACCOUNT_ID                    int(11)         NOT NULL,
  RESERVATION_DATE              datetime        NOT NULL,
  RESERVATION_AMOUNT            decimal(16,2)   DEFAULT NULL,
  SECURED_RESERVATION_AMOUNT    decimal(16,2)   DEFAULT NULL,
  UNSECURED_RESERVATION_AMOUNT  decimal(16,2)   DEFAULT NULL,
  DECLARATION_TYPE              varchar(35)     NOT NULL,  -- check constraint & comment or fk to ref data
  DATETIME                      datetime        NOT NULL,
  CLAIMED                       char(1) NOT     NULL DEFAULT '0',  -- check constraint & comment
  RELEASE_RESERVATION           char(1) NOT     NULL,  -- check constraint & comment
  
  PRIMARY KEY (RESERVATION_ID),
  KEY FK_PYMT_SCHEDULE_A_C (ACCOUNT_ID),
  CONSTRAINT FK_PYMT_SCHEDULE_A_C FOREIGN KEY (ACCOUNT_ID) REFERENCES ACCOUNT (ACCOUNT_ID)
);


CREATE TABLE RESERVATION_DUTY (
  DUTY_TYPE_ID              int(11)         NOT NULL AUTO_INCREMENT,
  RESERVATION_ID            int(11)         NOT NULL,
  DUTY_TYPE                 varchar(5)      NOT NULL,  -- check constraint & comment or fk to ref data
  AMOUNT                    decimal(16,2)   NOT NULL,
  
  PRIMARY KEY (DUTY_TYPE_ID),
  KEY FK_RESERVATION_DUTY_TYPE (RESERVATION_ID),
  CONSTRAINT FK_RESERVATION_DUTY_TYPE FOREIGN KEY (RESERVATION_ID) REFERENCES RESERVATION (RESERVATION_ID)
);


CREATE TABLE SUBSCRIPTION (
  SUBSCRIPTION_ID           int(11)         NOT NULL AUTO_INCREMENT,
  ACCOUNT_ALTERNATE_NUMBER  varchar(17)     NOT NULL, -- comment
  EORI                      varchar(17)     NOT NULL,
  SUBSCRIPTION_AMOUNT       decimal(16,2)   NOT NULL,
  SUBSCRIPTION_TARGET       char(1)         NOT NULL,
  NOTIFICATION_SENT_FLAG    tinyint(1)      DEFAULT NULL,  -- check constraint & comment
  SERVICE_REQUEST_ID        varchar(50)     NOT NULL,
  SRQ_STATUS_TYPE           varchar(15)     DEFAULT NULL,  -- check constraint & comment or fk to ref data
  SRQ_SEQUENCE_NUMBER       bigint(20)      DEFAULT NULL,
  SRQ_DATE_TIME             datetime        DEFAULT NULL,
  SRQ_EXTERNAL_ID           varchar(50)     DEFAULT NULL,
  
  PRIMARY KEY (SUBSCRIPTION_ID)
);
