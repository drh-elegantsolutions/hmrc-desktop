/****************************************/
/*                                      */
/* Stored Procedures                    */
/*                                      */
/* FUNCTION  CREATE_GAN                 */
/* FUNCTION  reportErrors               */
/* PROCEDURE ADD_ACCOUNT_LIMIT          */
/* PROCEDURE ADD_ACCOUNT_USER           */
/* PROCEDURE ADD_CONTACT_ADDRESS        */
/* PROCEDURE ADD_GUARANTEE              */
/* PROCEDURE ADD_GUARANTEE_LIMIT        */
/* PROCEDURE CREATE_DAN                 */
/* PROCEDURE IDENTIFY_ACCOUNT           */
/* PROCEDURE IDENTIFY_ACCOUNT_LIMITS    */
/* PROCEDURE IDENTIFY_ACCOUNT_STATUSES  */
/* PROCEDURE IDENTIFY_ADDRESSES         */
/* PROCEDURE IDENTIFY_GUARANTEES        */
/* PROCEDURE IDENTIFY_GUARANTEE_LIMITS  */
/* PROCEDURE initialiseErrorStore       */
/* PROCEDURE nullCheck                  */
/* PROCEDURE rangeCheck                 */
/* PROCEDURE REMOVE_ACCOUNT_LIMIT       */
/* PROCEDURE REMOVE_ACCOUNT_STATUS      */
/* PROCEDURE REMOVE_ACCOUNT_USER        */
/* PROCEDURE REMOVE_CONTACT_ADDRESS     */
/* PROCEDURE REMOVE_GUARANTEE           */
/* PROCEDURE REMOVE_GUARANTEE_LIMIT     */
/* PROCEDURE SET_ACCOUNT_STATUS         */
/* PROCEDURE textCheck                  */
/* PROCEDURE UPDATE_ACCOUNT_LIMIT       */
/* PROCEDURE UPDATE_GUARANTEE_LIMIT     */
/****************************************/

/**
 * TODO: These need checking to see if we really need these, it *looks* like most of them can be removed
 * if not then a review of how they intersect with the application code that does the same thing
 */

CREATE FUNCTION `CREATE_GAN`() RETURNS varchar(12) CHARSET latin1
    DETERMINISTIC
BEGIN
   declare gifStr varchar(12) default '000000000000' ;
   declare maxId int default 0 ;
   
SELECT 
    MAX(GUARANTEE_INTERNAL_REFERENCE)
INTO gifStr FROM
    `guarantee_limit`;
    if gifStr is null 
    then
		set gifStr = '0';
        end if;
    set maxId = convert(gifStr , UNSIGNED);

   RETURN LPAD((maxId +1), 12, '0'); 
   END ;;

CREATE FUNCTION `reportErrors`() RETURNS varchar(4000) CHARSET latin1
BEGIN
    DECLARE l_errors INT;
    DECLARE l_buffer VARCHAR(4000);
    DECLARE l_text   VARCHAR(100);
    DECLARE l_done BOOLEAN DEFAULT 0;
    DECLARE c_err cursor FOR 
        Select text from error_store;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET l_done = 1;

    
    Select count(*) into l_errors from error_store;
    IF (l_errors = 0) THEN
        RETURN null;
    END IF;

    IF (l_errors = 1) THEN
        SET l_buffer := 'One error was found in the parameters:';
    ELSE
        SET l_buffer := CONCAT(l_errors, ' errors were found in the parameters:');
    END IF;
    
    OPEN c_err;

    read_loop: LOOP
        FETCH c_err INTO l_text;
        IF l_done THEN
            LEAVE read_loop;
        END IF;
        set l_buffer := CONCAT(l_buffer, '\n   - ', l_text, '.');
    END LOOP;

    close c_err;
    
    RETURN l_buffer;
END ;;

CREATE PROCEDURE `ADD_ACCOUNT_LIMIT`(
    
    IN  p_accountID_i      INT(11), 
    
    IN  p_effectiveFrom_i  DATETIME, 
    IN  p_effectiveTo_i    DATETIME, 
    IN  p_accountLimit_i   DECIMAL(16,2),
    IN  p_changeReason_i   VARCHAR(30), 
    IN  p_actionType_i     SMALLINT, 
    
    OUT p_result_o         VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Account ID',          p_accountID_i    );
    call nullCheck ('Effective From Date', p_effectiveFrom_i);
    call rangeCheck('Effective From Date', p_effectiveFrom_i, 'Effective To Date', p_effectiveTo_i);
    call textCheck ('Change Reason',       p_changeReason_i, true, 1, 30);
    IF (p_actionType_i is not null and NOT p_actionType_i between 0 and 9) THEN
        insert into error_store 
        select CONCAT('The Action Type must be in the range 0 - 9 (found ', p_actionType_i, ')');
    END IF;
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No account record could be found with ACCOUNT_ID ', p_accountID_i, ' to add an account limit to.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''account_limit'' record for ACCOUNT_ID ', p_accountID_i, ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date.'
    );

    
    Select count(*) into l_rowCount
    From account_limit
    Where ACCOUNT_ID = p_accountID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
    IF (l_rowCount > 0) THEN
        Set p_result_o = CONCAT('There is already an ', l_description, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `account_limit` values (
        p_accountID_i,      
        p_effectiveFrom_i,  
        p_effectiveTo_i, 
        p_accountLimit_i,   
        p_changeReason_i, 
        sysdate(),          
        p_actionType_i
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''account_limit'' record has been created with', 
            '\n              ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                                       '(NULL)'), 
            '\n          EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n            EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n    ACCOUNT_LIMIT_AMOUNT: ', IFNULL(ACCOUNT_LIMIT_AMOUNT,                             '(NULL)'), 
            '\n       REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'), 
            '\n            CREATED_DATE: ', IFNULL(DATE_FORMAT(CREATED_DATE,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n             ACTION_TYPE: ', IFNULL(ACTION_TYPE,                                      '(NULL)'))
        Into p_result_o
        From account_limit
        Where ACCOUNT_ID = p_accountID_i
          and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''account_limit'' record (ACCOUNT_ID ', p_accountID_i, 
                ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date) could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `ADD_ACCOUNT_USER`(
    
    IN  p_accountID_i       INT(11), 
    
    IN  p_partyEori_i       VARCHAR(17), 
    IN  p_permissionType_i  VARCHAR(35), 
    IN  p_effectiveFrom_i   DATETIME, 
    IN  p_effectiveTo_i     DATETIME, 
    IN  p_viewBalance_i     CHAR(1), 
    
    OUT p_result_o          VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description   VARCHAR(4000);
    declare l_rowCount      INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Account ID',              p_accountID_i                    );
    call textCheck ('Party EORI',              p_partyEori_i ,     false, 1,  17);
    call textCheck ('Account permission Type', p_permissionType_i, true,  1, 100);
    call nullCheck ('Effective From Date',     p_effectiveFrom_i                );
    call rangeCheck('Effective From Date', p_effectiveFrom_i, 'Effective To Date', p_effectiveTo_i);
    call nullCheck ('View Balance',            p_viewBalance_i                  );
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No account record could be found with ACCOUNT_ID ', p_accountID_i, ' to add an account user to.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''account_user'' record for Account ID ', p_accountID_i, 
        ' with Party EORI ''', p_partyEori_i, ''' and Effective Date ''', p_effectiveFrom_i, '''.'
    );

    
    Select count(*) into l_rowCount
    From account_user
    Where ACCOUNT_ID = p_accountID_i
      and PARTY_EORI = p_partyEori_i
      and DATE(EFFECTIVE_FROM) = DATE(p_effectiveFrom_i);
    IF (l_rowCount > 0) THEN
        Set p_result_o = CONCAT('There is already an ', l_description, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `account_user` values (
        p_accountID_i,        
        p_partyEori_i,        
        p_permissionType_i,   
        p_effectiveFrom_i,    
        p_effectiveTo_i,      
        p_viewBalance_i       
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''account_user'' record has been created with', 
            '\n               ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                                       '(NULL)'), 
            '\n               PARTY_EORI: ', IFNULL(PARTY_EORI,                                       '(NULL)'), 
            '\n  ACCOUNT_PERMISSION_TYPE: ', IFNULL(ACCOUNT_PERMISSION_TYPE,                          '(NULL)'), 
            '\n           EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n             EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n             VIEW_BALANCE: ', IFNULL(VIEW_BALANCE,                                     '(NULL)'))
        Into p_result_o
        From account_user
        Where ACCOUNT_ID = p_accountID_i
          and PARTY_EORI = p_partyEori_i
          and ((ACCOUNT_PERMISSION_TYPE is null and p_permissionType_i is null) or ACCOUNT_PERMISSION_TYPE = p_permissionType_i)
          and EFFECTIVE_FROM = p_effectiveFrom_i;
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''account_user'' record (with ACCOUNT_ID ', p_accountID_i, 
                ' and PARTY_EORI ''', p_partyEori_i, ''') could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `ADD_CONTACT_ADDRESS`(
    
    IN  p_accountID_i     INT(11), 
    
    IN  p_addressLine1_i  VARCHAR(35), 
    IN  p_addressLine2_i  VARCHAR(35), 
    IN  p_addressLine3_i  VARCHAR(35), 
    IN  p_postcode_i      VARCHAR(35),
    IN  p_countryCode_i   VARCHAR(2),
    IN  p_addressType_i   SMALLINT(6),
    
    OUT p_result_o        VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description   VARCHAR(4000);
    declare l_rowCount      INT2;
    call initialiseErrorStore();

    
    call nullCheck('Account ID',      p_accountID_i                 );
    call textCheck('Address Line1 1', p_addressLine1_i, false, 1, 35);
    call textCheck('Address Line1 2', p_addressLine2_i, true,  1, 35);
    call textCheck('Address Line1 3', p_addressLine3_i, true,  1, 35);
    call textCheck('Postcode',        p_postcode_i,     true,  1, 35);
    call textCheck('Country Code',    p_countryCode_i,  true,  2,  2);
    call nullCheck('Address Type',    p_addressType_i               );
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No account record could be found with ACCOUNT_ID ', p_accountID_i, ' to add an address to.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''address'' record with first line ''', p_addressLine1_i, ''' and Type ''', p_addressType_i, '''.'
    );

    
    Select count(*) into l_rowCount
    From address
    Where ACCOUNT_ID   = p_accountID_i
      and ADDRESSLINE1 = p_addressLine1_i
      and ((ADDRESSLINE2 is null and p_addressLine2_i is null) or ADDRESSLINE2 = p_addressLine2_i)
      and ((ADDRESSLINE3 is null and p_addressLine3_i is null) or ADDRESSLINE3 = p_addressLine3_i)
      and ((POSTCODE     is null and p_postcode_i     is null) or POSTCODE     = p_postcode_i)
      and ((COUNTRYCODE  is null and p_countryCode_i  is null) or COUNTRYCODE  = p_countryCode_i)
      and ADDRESS_TYPE = p_addressType_i;
    IF (l_rowCount > 0) THEN
        Set p_result_o = CONCAT('There is already an ', l_description, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `address` values (
        null,               
        p_accountID_i,      
        p_addressLine1_i,   
        p_addressLine2_i,   
        p_addressLine3_i,   
        p_postcode_i,       
        p_countryCode_i,    
        p_addressType_i     
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''address'' record has been created with', 
            '\n      ADDRESS_ID: ', IFNULL(ADDRESS_ID,   '(NULL)'), 
            '\n      ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,   '(NULL)'), 
            '\n    ADDRESSLINE1: ', IFNULL(ADDRESSLINE1, '(NULL)'), 
            '\n    ADDRESSLINE2: ', IFNULL(ADDRESSLINE2, '(NULL)'), 
            '\n    ADDRESSLINE3: ', IFNULL(ADDRESSLINE3, '(NULL)'), 
            '\n        POSTCODE: ', IFNULL(POSTCODE,     '(NULL)'), 
            '\n     COUNTRYCODE: ', IFNULL(COUNTRYCODE,  '(NULL)'), 
            '\n    ADDRESS_TYPE: ', IFNULL(ADDRESS_TYPE, '(NULL)'))
        Into p_result_o
        From address
        Where ADDRESS_ID = LAST_INSERT_ID();
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''address'' record (with ADDRESS_ID ', LAST_INSERT_ID(), ') could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `ADD_GUARANTEE`(
    
    IN  p_accountID_i     INT(11), 
    
    IN  p_guarantorID_i   VARCHAR(10), 
    IN  p_permanentInd_i  CHAR(1), 
    
    OUT p_result_o        VARCHAR(4000)    
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck('Account ID',                    p_accountID_i                );
    call textCheck('Guarantor ID',                  p_guarantorID_i, false, 1, 10);
    call nullCheck('Permanent Guarantee Indicator', p_permanentInd_i             );
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No ''account'' record could be found with ACCOUNT_ID ', p_accountID_i, ' to associate a ''gurantee'' with.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''account'' record for ACCOUNT_ID ', p_accountID_i, ' and GUARANTOR_ID ', p_guarantorID_i);

    
    Select count(*) into l_rowCount
    From guarantee
    Where ACCOUNT_ID   = p_accountID_i
      and GUARANTOR_ID = p_guarantorID_i;
    IF (l_rowCount > 0) THEN
        Set p_result_o = CONCAT('There is already an ', l_description, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `guarantee` values (
        null,               
        p_accountID_i,      
        p_guarantorID_i,    
        p_permanentInd_i    
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''guarantee'' record has been created with', 
            '\n                     GUARANTEE_ID: ', IFNULL(GUARANTEE_ID,                  '(NULL)'), 
            '\n                       ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                    '(NULL)'), 
            '\n                     GUARANTOR_ID: ', IFNULL(GUARANTOR_ID,                  '(NULL)'), 
            '\n    PERMANENT_GUARANTEE_INDICATOR: ', IFNULL(PERMANENT_GUARANTEE_INDICATOR, '(NULL)'))
        Into p_result_o
        From guarantee
        Where ACCOUNT_ID   = p_accountID_i
          and GUARANTOR_ID = p_guarantorID_i;
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''guarantee'' record (ACCOUNT_ID ', p_accountID_i, 
                ' and GUARANTOR_ID ', p_guarantorID_i, ' could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `ADD_GUARANTEE_LIMIT`(
    
    IN  p_guaranteeID_i        INT(11), 
    
    IN  p_effectiveFrom_i      DATETIME, 
    IN  p_effectiveTo_i        DATETIME, 
    IN  p_guaranteeLimit_i     DECIMAL(16,2), 
    IN  p_referenceNumber_i    VARCHAR(40), 
    IN  p_internalReference_i  VARCHAR(12), 
    IN  p_changeReason_i       VARCHAR(30), 
    
    OUT p_result_o             VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_pk           INT(11);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Guarantee ID',        p_guaranteeID_i   );
    call nullCheck ('Effective From Date', p_effectiveFrom_i );
    call rangeCheck('Effective From Date', p_effectiveFrom_i, 'Effective To Date', p_effectiveTo_i);
    call textCheck ('Reference Number',    p_referenceNumber_i,   true, 1, 40);
    call textCheck ('Internal Reference',  p_internalReference_i, true, 1, 12);
    call textCheck ('Change Reason',       p_changeReason_i,      true, 1, 30);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    Set l_description := CONCAT('GUARANTEE_ID ', p_guaranteeID_i);

    
    Select count(*) into l_rowCount
    From guarantee
    Where GUARANTEE_ID = p_guaranteeID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No ''guarantee'' record could be found with GUARANTEE_ID ', p_guaranteeID_i, ' to associate a ''gurantee limit'' with.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''guarantee_limit'' record for GUARANTEE_ID ', p_guaranteeID_i, ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date'
    );

    
    Select max(GUARANTEE_LIMIT_ID) into l_pk
    From guarantee_limit
    Where GUARANTEE_ID = p_guaranteeID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
    IF (l_pk > 0) THEN
        Set p_result_o = CONCAT('There is already a ', l_description, ', with GUARANTEE_LIMIT_ID ', l_pk, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `guarantee_limit` values (
        null,                   
        p_guaranteeID_i,        
        p_effectiveFrom_i,      
        p_effectiveTo_i, 
        p_guaranteeLimit_i,     
        p_referenceNumber_i,    
        p_internalReference_i,  
        p_changeReason_i        
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''guarantee_limit'' record has been created with', 
            '\n              GUARANTEE_LIMIT_ID: ', IFNULL(GUARANTEE_LIMIT_ID,                               '(NULL)'), 
            '\n                    GUARANTEE_ID: ', IFNULL(GUARANTEE_ID,                                     '(NULL)'), 
            '\n                  EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n                    EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n                 GUARANTEE_LIMIT: ', IFNULL(GUARANTEE_LIMIT,                                  '(NULL)'), 
            '\n      GUARANTEE_REFERENCE_NUMBER: ', IFNULL(GUARANTEE_REFERENCE_NUMBER,                       '(NULL)'), 
            '\n    GUARANTEE_INTERNAL_REFERENCE: ', IFNULL(GUARANTEE_INTERNAL_REFERENCE,                     '(NULL)'), 
            '\n               REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'))
        Into p_result_o
        From guarantee_limit
        Where GUARANTEE_ID = p_guaranteeID_i
          and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''guarantee_limit'' record (GUARANTEE_ID ', p_guaranteeID_i, 
                ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date) could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `CREATE_DAN`(
    
    IN  p_alternateNumber_i  VARCHAR(100), 
    IN  p_accountName_i      VARCHAR(500), 
    IN  p_traderName_i       VARCHAR(500), 
    IN  p_accountType_i      VARCHAR(500), 
    IN  p_effectiveFrom_i    DATETIME, 
    IN  p_effectiveTo_i      DATETIME, 
    IN  p_changeReason_i     VARCHAR(30),
    
    OUT p_result_o           VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call textCheck ('Alternate Account Number', p_alternateNumber_i, false, 1,  17);
    call textCheck ('Account Name',             p_accountName_i,     true,  1, 100);
    call textCheck ('Trader Name',              p_traderName_i,      true,  1, 100);
    call textCheck ('Account Type',             p_accountType_i,     false, 1, 100);
    call nullCheck ('Effective From Date',      p_effectiveFrom_i);
    call textCheck ('Change Reason',            p_changeReason_i,    true,  1, 250);
    call rangeCheck('Effective From Date', p_effectiveFrom_i, 'Effective To Date', p_effectiveTo_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Set p_effectiveFrom_i := DATE(p_effectiveFrom_i);
    Set p_effectiveTo_i   := DATE(p_effectiveTo_i);

    
    Set l_description := CONCAT(
        '''account'' record with the Account Name ''', p_accountName_i, 
        ''', Trader Name ''', p_traderName_i, ''' and Account Type ''', p_accountType_i, '''.'
    );

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_NAME = p_accountName_i
      and TRADER_NAME  = p_traderName_i
      and ACCOUNT_TYPE = p_accountType_i;
    IF (l_rowCount > 0) THEN
        Set p_result_o = CONCAT('There is already an ', l_description, ' The duplicate will not be added.');
        leave proc_label;
    END IF;

    
    Insert into `account` values (
        null, 
        p_alternateNumber_i, 
        p_accountName_i, 
        p_traderName_i, 
        p_accountType_i, 
        p_effectiveFrom_i, 
        p_effectiveTo_i, 
        p_changeReason_i
    );
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was inserted for the new ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. A new ''account'' record has been created with', 
            '\n                ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                                       '(NULL)'), 
            '\n  ACCOUNT_ALTERNATE_NUMBER: ', IFNULL(ACCOUNT_ALTERNATE_NUMBER,                         '(NULL)'), 
            '\n              ACCOUNT_NAME: ', IFNULL(ACCOUNT_NAME,                                     '(NULL)'), 
            '\n               TRADER_NAME: ', IFNULL(TRADER_NAME,                                      '(NULL)'), 
            '\n              ACCOUNT_TYPE: ', IFNULL(ACCOUNT_TYPE,                                     '(NULL)'), 
            '\n            EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n              EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n         REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'))
        Into p_result_o
        From account
        Where ACCOUNT_ID = LAST_INSERT_ID();
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''account'' record (with ACCOUNT_ID ', LAST_INSERT_ID(), ') could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `IDENTIFY_ACCOUNT`(
    IN  p_alternateNumber_i  VARCHAR(17), 
    IN  p_accountName_i      VARCHAR(100), 
    IN  p_traderName_i       VARCHAR(100)
)
BEGIN
    DECLARE l_select VARCHAR(5000);

    IF p_alternateNumber_i is NOT null THEN
        IF LOCATE('%', p_alternateNumber_i) > 0 OR LOCATE('_', p_alternateNumber_i) > 0 THEN
            Set l_select = CONCAT(' ACCOUNT_ALTERNATE_NUMBER like ''', p_alternateNumber_i, '''');
        ELSE
            Set l_select = CONCAT(' ACCOUNT_ALTERNATE_NUMBER = ''', p_alternateNumber_i, '''');
        END IF;
    END IF;

    IF p_accountName_i is NOT null THEN
        IF l_select is NOT null THEN
            Set l_select = CONCAT(l_select, ' and ');
        END IF;
        IF LOCATE('%', p_alternateNumber_i) > 0 OR LOCATE('_', p_alternateNumber_i) > 0 THEN
            Set l_select = CONCAT(l_select, ' ACCOUNT_NAME like ''', p_accountName_i, '''');
        ELSE
            Set l_select = CONCAT(l_select, ' ACCOUNT_NAME = ''', p_accountName_i, '''');
        END IF;
    END IF;

    IF p_traderName_i is NOT null THEN
        IF l_select is NOT null THEN
            Set l_select = CONCAT(l_select, ' and ');
        END IF;
        IF LOCATE('%', p_alternateNumber_i) > 0 OR LOCATE('_', p_alternateNumber_i) > 0 THEN
            Set l_select = CONCAT(l_select, ' TRADER_NAME like ''', p_traderName_i, '''');
        ELSE
            Set l_select = CONCAT(l_select, ' TRADER_NAME = ''', p_traderName_i, '''');
        END IF;
    END IF;

    IF l_select is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'At least one of ACCOUNT_ALTERNATE_NUMBER, ACCOUNT_NAME or TRADER_NAME is required.';
    END IF;

    Set @l_select = CONCAT('Select * from account Where', l_select);

    PREPARE statement FROM @l_select;
    EXECUTE statement;
    DEALLOCATE PREPARE statement;

END ;;

CREATE PROCEDURE `IDENTIFY_ACCOUNT_LIMITS`(
    IN  p_accountID_i  INT(11)
)
BEGIN
    IF p_accountID_i is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'The ACCOUNT_ID of the Account Limit(s) to be found is required. Try using IDENTIFY_ACCOUNT() to find this.';
    END IF;

    Select * from account_limit
    Where ACCOUNT_ID = p_accountID_i;
END ;;

CREATE PROCEDURE `IDENTIFY_ACCOUNT_STATUSES`(
    IN  p_accountID_i  INT(11)
)
BEGIN
    IF p_accountID_i is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'The ACCOUNT_ID of the Account Statuses'' parent Account is required. Try using IDENTIFY_ACCOUNT() to find this.';
    END IF;

    Select * from account_status
    Where ACCOUNT_ID = p_accountID_i;
END ;;

CREATE PROCEDURE `IDENTIFY_ADDRESSES`(
    IN  p_accountID_i  INT(11)
)
BEGIN
    IF p_accountID_i is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'The ACCOUNT_ID of the address(es) to be found is required. Try using IDENTIFY_ACCOUNT() to find this.';
    END IF;

    Select * from address 
    Where ACCOUNT_ID = p_accountID_i;
END ;;

CREATE PROCEDURE `IDENTIFY_GUARANTEES`(
    IN  p_accountID_i  INT(11)
)
BEGIN
    IF p_accountID_i is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'The ACCOUNT_ID of the Guarantee(s) to be found is required. Try using IDENTIFY_ACCOUNT() to find this.';
    END IF;

    Select * from guarantee
    Where ACCOUNT_ID = p_accountID_i;
END ;;

CREATE PROCEDURE `IDENTIFY_GUARANTEE_LIMITS`(
    IN  p_guaranteeID_i  INT(11)
)
BEGIN
    IF p_guaranteeID_i is null THEN
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'The parent GUARANTEE_ID is required. Try using IDENTIFY_GUARANTEES(INT) with the Account ID to find this.';
    END IF;

    Select * from guarantee_limit
    Where GUARANTEE_ID = p_guaranteeID_i;
END ;;

CREATE PROCEDURE `initialiseErrorStore`(
)
BEGIN
    CREATE TEMPORARY TABLE IF NOT EXISTS error_store (
        text  VARCHAR(100)
    );
    TRUNCATE error_store;
END ;;

CREATE PROCEDURE `nullCheck`(
    IN  p_fieldName  VARCHAR(30), 
    IN  p_textValue  VARCHAR(1000)
)
BEGIN
    IF p_textValue IS NULL THEN
        Insert into error_store values (CONCAT('''', p_fieldName, ''' is not allowed null'));
    END IF;
END ;;

CREATE PROCEDURE `rangeCheck`(
    IN  p_startName  VARCHAR(30), 
    IN  p_startDate  datetime, 
    IN  p_endName    VARCHAR(30), 
    IN  p_endDate    datetime
)
begin
    IF p_startDate is not null and p_endDate is not null and DATE(p_endDate) < DATE(p_startDate) THEN
        insert into error_store 
        select CONCAT('The ', p_endName, ' cannot be before the ', p_startName);
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_ACCOUNT_LIMIT`(
    
    IN  p_accountID_i      INT(11),
    IN  p_effectiveFrom_i  DATETIME, 
    
    OUT p_result_o         VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Account ID',          p_accountID_i    );
    call nullCheck ('Effective From Date', p_effectiveFrom_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    Set l_description := CONCAT('ACCOUNT_ID ', p_accountID_i, ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date');

    
    Select count(*) into l_rowCount
    From account_limit
    Where ACCOUNT_ID = p_accountID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No ''account_limit'' record could be found with ', l_description, ' to remove.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''account_limit'' record with ', l_description, '.');

    
    Delete from account_limit
    Where ACCOUNT_ID = p_accountID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be removed trying to remove the ', l_description, ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select count(*) into l_rowCount
        From account_limit
        Where ACCOUNT_ID = p_accountID_i
          and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_ACCOUNT_STATUS`(
    
    IN  p_accountID_i      int(11), 
    IN  p_effectiveFrom_i  datetime, 
    
    OUT p_result_o         VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck('Account ID',          p_accountID_i    );
    call nullCheck('Effective From Date', p_effectiveFrom_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Set p_effectiveFrom_i := DATE(p_effectiveFrom_i);

    Set l_description := CONCAT(
        'ACCOUNT_ID ', p_accountID_i, ' and EFFECTIVE_FROM date ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y")
    );

    
    Select count(*) into l_rowCount
    From account_status
    Where ACCOUNT_ID = p_accountID_i
      and DATE(EFFECTIVE_FROM) = p_effectiveFrom_i;
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No ''account_status'' record could be found with ', l_description, ' to remove.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''account_status'' record with ', l_description, '.');

    
    Delete from account_status
    Where ACCOUNT_ID = p_accountID_i
      and DATE(EFFECTIVE_FROM) = p_effectiveFrom_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSE
        
        IF (l_rowCount > 1) THEN
            set p_result_o = CONCAT(l_rowCount, ' rows matching ');
        ELSE
            set p_result_o = '';
        END IF;

        
        Select count(*) into l_rowCount
        From account_status
        Where ACCOUNT_ID = p_accountID_i
          and DATE(EFFECTIVE_FROM) = p_effectiveFrom_i;
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed ', p_result_o, 'the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_ACCOUNT_USER`(
    
    IN  p_accountID_i       INT(11), 
    IN  p_partyEori_i       VARCHAR(17), 
    IN  p_permissionType_i  VARCHAR(35), 
    IN  p_effectiveFrom_i   DATETIME, 
    
    OUT p_result_o     VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description   VARCHAR(4000);
    declare l_rowCount      INT2;
    call initialiseErrorStore();

    
    call nullCheck('Account ID',          p_accountID_i);
    call nullCheck('Effective From Date', p_effectiveFrom_i);
    call textCheck('Party EORI', p_partyEori_i, false, 1,  17);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
        leave proc_label;
    END IF;

    
    Set p_effectiveFrom_i := DATE(p_effectiveFrom_i);

    Set l_description := CONCAT('''account_user'' record with ACCOUNT_ID ', p_accountID_i, ', PARTY_EORI ''', p_partyEori_i, ''', ');
    IF (p_permissionType_i IS null) THEN
        Set l_description := CONCAT(l_description, 'no ACCOUNT_PERMISSION_TYPE');
    ELSE
        Set l_description := CONCAT(l_description, 'ACCOUNT_PERMISSION_TYPE ', p_permissionType_i);
    END IF;
    Set l_description := CONCAT(l_description, ' and EFFECTIVE_FROM ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"));

    
    Select count(*) into l_rowCount
    From account_user
    Where ACCOUNT_ID = p_accountID_i
      and PARTY_EORI = p_partyEori_i
      and ((ACCOUNT_PERMISSION_TYPE is null and p_permissionType_i is null) or ACCOUNT_PERMISSION_TYPE = p_permissionType_i)
      and EFFECTIVE_FROM = p_effectiveFrom_i;
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No ', l_description, ' could be found to remove.');
        leave proc_label;
    END IF;

    
    Delete from account_user
    Where ACCOUNT_ID = p_accountID_i
      and PARTY_EORI = p_partyEori_i
      and ((ACCOUNT_PERMISSION_TYPE is null and p_permissionType_i is null) or ACCOUNT_PERMISSION_TYPE = p_permissionType_i)
      and EFFECTIVE_FROM = p_effectiveFrom_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be removed trying to remove the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select count(*) into l_rowCount
        From account_user
        Where ACCOUNT_ID = p_accountID_i
          and PARTY_EORI = p_partyEori_i
          and ((ACCOUNT_PERMISSION_TYPE is null and p_permissionType_i is null) or ACCOUNT_PERMISSION_TYPE = p_permissionType_i)
          and EFFECTIVE_FROM = p_effectiveFrom_i;
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_CONTACT_ADDRESS`(
    
    IN  p_addressID_i     INT(11), 
    
    OUT p_result_o          VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description   VARCHAR(4000);
    declare l_rowCount      INT2;
    call initialiseErrorStore();

    
    call nullCheck('Address ID', p_addressID_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From address
    Where ADDRESS_ID = p_addressID_i;
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No address record could be found with ADDRESS_ID ', p_addressID_i, ' to remove.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''address'' record with ADDRESS_ID ', p_addressID_i, '.');

    
    Delete from address
    Where ADDRESS_ID = p_addressID_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be removed trying to remove the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select count(*) into l_rowCount
        From address
        Where ADDRESS_ID = p_addressID_i;
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_GUARANTEE`(
    
    IN  p_guaranteeID_i  INT(11), 
    
    OUT p_result_o       VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck('Guarantee ID', p_guaranteeID_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From guarantee
    Where GUARANTEE_ID = p_guaranteeID_i;
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No ''guarantee'' record could be found with GUARANTEE_ID ', p_guaranteeID_i, ' to remove.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''guarantee'' record with GUARANTEE_ID ', p_guaranteeID_i, '.');

    
    Delete from guarantee
    Where GUARANTEE_ID = p_guaranteeID_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be removed trying to remove the ', l_description, ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select count(*) into l_rowCount
        From guarantee
        Where GUARANTEE_ID = p_guaranteeID_i;
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `REMOVE_GUARANTEE_LIMIT`(
    
    IN  p_guaranteeLimitID_i  INT(11), 
    
    OUT p_result_o            VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck  ('Guarantee Limit ID',  p_guaranteeLimitID_i);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From guarantee_limit
    Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT('No ''guarantee_limit'' record could be found with GUARANTEE_LIMIT_ID ', p_guaranteeLimitID_i, ' to remove.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''guarantee_limit'' record with GUARANTEE_LIMIT_ID ', p_guaranteeLimitID_i, '.');

    
    Delete from guarantee_limit
    Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No record was deleted trying to remove the ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be removed trying to remove the ', l_description, ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select count(*) into l_rowCount
        From guarantee_limit
        Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
        IF (l_rowCount = 0) THEN
            Set p_result_o = CONCAT('Success. Removed the ', l_description);
        ELSE
            Set p_result_o = CONCAT(
                'Remove failed! The deletion appeared to complete successfully, but a record could still be found for the ', 
                l_description
            );
            rollback;
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `SET_ACCOUNT_STATUS`(
    
    IN  p_accountID_i      INT(11), 
    
    IN  p_statusTypeID_i   SMALLINT(6), 
    IN  p_effectiveFrom_i  DATE, 
    IN  p_changeReason_i   VARCHAR(30), 
    
    OUT p_result_o         VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description   VARCHAR(4000);
    declare l_rowCount      INT2 DEFAULT 0;
    declare l_previousFrom  DATETIME;

    call initialiseErrorStore();

    
    call nullCheck ('Account ID',             p_accountID_i    );
    call nullCheck ('Account Status Type ID', p_statusTypeID_i );
    call nullCheck ('Effective From Date',    p_effectiveFrom_i);
    call textCheck ('Change Reason', p_changeReason_i, true, 1, 30);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No ''account'' record could be found with ACCOUNT_ID ', p_accountID_i, ' to associate a ''account_status'' with.');
        leave proc_label;
    END IF;

    
    Set p_effectiveFrom_i := DATE(p_effectiveFrom_i);

    Select count(*) into l_rowCount
    From account_status
    Where ACCOUNT_ID = p_accountID_i
      and EFFECTIVE_FROM >= p_effectiveFrom_i;
    IF (l_rowCount > 0) THEN
        IF (l_rowCount = 1) THEN
            Set p_result_o = CONCAT('There is already an ''account_status'' record');
        ELSE
            Set p_result_o = CONCAT('There are already ', l_rowCount, ' ''account_status'' records');
        END IF;
        Set p_result_o = CONCAT(p_result_o, ' effecive from the same time or later than the requested date.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''account_status'' record for ACCOUNT_ID ', p_accountID_i, ', ACCOUNT_STATUS_TYPE_ID ', p_statusTypeID_i, 
        ' and EFFECTIVE_FROM ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y")
    );

    
    Select max(EFFECTIVE_FROM) into l_previousFrom
    From account_status
    Where ACCOUNT_ID = p_accountID_i;
    IF (l_previousFrom is NOT null) THEN
        Update account_status
        Set EFFECTIVE_TO = p_effectiveFrom_i - INTERVAL 1 DAY
        Where ACCOUNT_ID     =  p_accountID_i
          and EFFECTIVE_FROM >= l_previousFrom;
    END IF;

    
    Insert into `account_status` values (
        p_accountID_i,      
        p_statusTypeID_i,   
        p_effectiveFrom_i,  
        null,               
        p_changeReason_i
    );

    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        set p_result_o = CONCAT('No new entry was created for an ', l_description, ' (No reason available.)');
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be created trying to add an entry for the ', l_description, 
            ' (No reason available.)'
        );
        ROLLBACK;
    ELSE
        
        Select count(*) into l_rowCount
        From account_status
        Where ACCOUNT_ID             = p_accountID_i
          and ACCOUNT_STATUS_TYPE_ID = p_statusTypeID_i
          and EFFECTIVE_FROM         = p_effectiveFrom_i;
        IF (l_rowCount > 1) THEN
            Set p_result_o = CONCAT(
                'Success reported, but ''account_status'' would have ', l_rowCount, ' records for ', l_description, '. Update cancelled.'
            );
            ROLLBACK;
            LEAVE proc_label;
        END IF;

        
        Select CONCAT(
            'Success. A new ''account_status'' record has been added with', 
            '\n                ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                                       '(NULL)'), 
            '\n    ACCOUNT_STATUS_TYPE_ID: ', IFNULL(ACCOUNT_STATUS_TYPE_ID,                           '(NULL)'), 
            '\n            EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n              EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n         REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'))
        Into p_result_o
        From account_status
        Where ACCOUNT_ID             = p_accountID_i
          and ACCOUNT_STATUS_TYPE_ID = p_statusTypeID_i
          and EFFECTIVE_FROM         = p_effectiveFrom_i;
        IF (p_result_o is null) THEN
            Set p_result_o = CONCAT(
                'Success reported, but the new ''account_status'' record (ACCOUNT_ID ', p_accountID_i, ', ACCOUNT_STATUS_TYPE_ID', 
                p_statusTypeID_i, ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date) could not be read back.'
            );
        END IF;
    END IF;

END ;;

CREATE PROCEDURE `textCheck`(
    IN  p_fieldName  VARCHAR(30), 
    IN  p_textValue  VARCHAR(1000), 
    IN  p_nullable   BOOLEAN, 
    IN  p_minLength  INT, 
    IN  p_maxLength  INT
)
BEGIN
    DECLARE l_too   VARCHAR(8);
    DECLARE l_span  VARCHAR(30);

    IF p_textValue IS NULL THEN
        IF NOT p_nullable THEN
            Insert into error_store values (CONCAT('''', p_fieldName, ''' is not allowed null'));
        END IF;
    ELSE
        IF NOT LENGTH(p_textValue) BETWEEN p_minLength AND p_maxLength THEN
            IF LENGTH(p_textValue) < p_minLength THEN
                Set l_too = 'short';
            ELSEIF length(p_textValue) > p_maxLength THEN
                set l_too = 'long';
            END IF;
            IF p_maxLength = p_minLength THEN
                Set l_span = CONCAT(p_maxLength, ' characters');
            ELSE
                Set l_span = CONCAT(p_minLength, '-', p_maxLength, ' characters');
            END IF;
            Insert into error_store values (CONCAT('''', p_fieldName, ''' is too ', l_too, '. Expected ', l_span, ', but found ', length(p_textValue)));
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `UPDATE_ACCOUNT_LIMIT`(
    
    IN  p_accountID_i      INT(11),
    IN  p_effectiveFrom_i  DATETIME, 
    
    IN  p_accountLimit_i  DECIMAL(16,2),
    IN  p_changeReason_i  VARCHAR(30),
    
    OUT p_result_o  VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Account ID',          p_accountID_i    );
    call nullCheck ('Effective From Date', p_effectiveFrom_i);
    call textCheck ('Change Reason',       p_changeReason_i, true, 1, 30);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From account_limit
    Where ACCOUNT_ID = p_accountID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
    IF (l_rowCount = 0) THEN
        Set p_result_o = CONCAT(
            'No account_limit record could be found for ACCOUNT_ID ', p_accountID_i, 
            ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date to adjust.'
        );
        leave proc_label;
    END IF;

    Set l_description := CONCAT(
        '''account_limit'' record for ACCOUNT_ID ', p_accountID_i, ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date.'
    );

    
    Update `account_limit`
    Set ACCOUNT_LIMIT_AMOUNT = p_accountLimit_i,    
        REASON_FOR_CHANGE    = p_changeReason_i
    Where ACCOUNT_ID = p_accountID_i
      and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
        
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        Select count(*) into l_rowCount
        From account_limit
        Where ACCOUNT_ID           = p_accountID_i
          and DATE(EFFECTIVE_FROM) = DATE(p_effectiveFrom_i)
          and ACCOUNT_LIMIT_AMOUNT = p_accountLimit_i
          and REASON_FOR_CHANGE    = p_changeReason_i;
        IF (l_rowCount > 0) THEN
            set p_result_o = CONCAT('No changes are being made for the ', l_description, ' (No update to apply.)');
        ELSE
            set p_result_o = CONCAT('No record was updated for the ', l_description, ' (No reason available.)');
        END IF;
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. The ''account_limit'' record has been updated with', 
            '\n              ACCOUNT_ID: ', IFNULL(ACCOUNT_ID,                                       '(NULL)'), 
            '\n          EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n            EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n    ACCOUNT_LIMIT_AMOUNT: ', IFNULL(ACCOUNT_LIMIT_AMOUNT,                             '(NULL)'), 
            '\n       REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'), 
            '\n            CREATED_DATE: ', IFNULL(DATE_FORMAT(CREATED_DATE,   "%d-%b-%Y %H:%i:%S"), '(NULL)'))
        Into p_result_o
        From account_limit
        Where ACCOUNT_ID = p_accountID_i
          and DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y") = DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y");
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the updated ''account_limit'' record (ACCOUNT_ID ', p_accountID_i, 
                ' and ', DATE_FORMAT(p_effectiveFrom_i, "%d-%b-%Y"), ' Start Date) could not be read back.'
            );
        END IF;
    END IF;
END ;;

CREATE PROCEDURE `UPDATE_GUARANTEE_LIMIT`(
    
    IN  p_guaranteeLimitID_i   INT(11), 
    
    IN  p_guaranteeLimit_i     DECIMAL(16,2), 
    IN  p_referenceNumber_i    VARCHAR(40), 
    IN  p_internalReference_i  VARCHAR(12), 
    IN  p_changeReason_i       VARCHAR(30), 
    
    OUT p_result_o             VARCHAR(4000)
)
proc_label:BEGIN
    
    declare l_description  VARCHAR(4000);
    declare l_rowCount     INT2;
    call initialiseErrorStore();

    
    call nullCheck ('Guarantee Limit ID',  p_guaranteeLimitID_i);
    call textCheck ('Reference Number',    p_referenceNumber_i,   true, 1, 40);
    call textCheck ('Internal Reference',  p_internalReference_i, true, 1, 12);
    call textCheck ('Change Reason',       p_changeReason_i,      true, 1, 30);
    set p_result_o := reportErrors();
    IF (p_result_o is not null) THEN
        leave proc_label;
    END IF;

    
    Select count(*) into l_rowCount
    From guarantee_limit
    Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
    IF (l_rowCount <> 1) THEN
        Set p_result_o = CONCAT('No guarantee_limit record could be found with the GUARANTEE_LIMIT_ID ', p_guaranteeLimitID_i, ' to update.');
        leave proc_label;
    END IF;

    Set l_description := CONCAT('''guarantee_limit'' record with GUARANTEE_LIMIT_ID ', p_guaranteeLimitID_i);

    
    Update `guarantee_limit`
    Set GUARANTEE_LIMIT              = p_guaranteeLimit_i,  
        GUARANTEE_REFERENCE_NUMBER   = p_referenceNumber_i,  
        GUARANTEE_INTERNAL_REFERENCE = p_internalReference_i, 
        REASON_FOR_CHANGE            = p_changeReason_i
    Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
    
    Select row_count() into l_rowCount;
    IF (l_rowCount < 1) THEN
        Select count(*) into l_rowCount
        From guarantee_limit
        Where GUARANTEE_LIMIT_ID           = p_guaranteeLimitID_i
          and GUARANTEE_LIMIT              = p_guaranteeLimit_i
          and GUARANTEE_REFERENCE_NUMBER   = p_referenceNumber_i
          and GUARANTEE_INTERNAL_REFERENCE = p_internalReference_i
          and REASON_FOR_CHANGE            = p_changeReason_i;
        IF (l_rowCount > 0) THEN
            Set p_result_o = CONCAT('No changes are being made for the ', l_description, ' (No updates to apply.)');
        ELSE
            Set p_result_o = CONCAT('No record was updated for the ', l_description, ' (No reason available.)');
        END IF;
    ELSEIF (l_rowCount > 1) THEN
        set p_result_o = CONCAT(
            'Multiple (', l_rowCount, ') rows would be updated trying to insert a new record for the ', l_description, 
            ' (No reason available.)'
        );
        rollback;
    ELSE
        
        Select CONCAT(
            'Success. The ''guarantee_limit'' record has been updated with', 
            '\n              GUARANTEE_LIMIT_ID: ', IFNULL(GUARANTEE_LIMIT_ID,                               '(NULL)'), 
            '\n                    GUARANTEE_ID: ', IFNULL(GUARANTEE_ID,                                     '(NULL)'), 
            '\n                  EFFECTIVE_FROM: ', IFNULL(DATE_FORMAT(EFFECTIVE_FROM, "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n                    EFFECTIVE_TO: ', IFNULL(DATE_FORMAT(EFFECTIVE_TO,   "%d-%b-%Y %H:%i:%S"), '(NULL)'), 
            '\n                 GUARANTEE_LIMIT: ', IFNULL(GUARANTEE_LIMIT,                                  '(NULL)'), 
            '\n      GUARANTEE_REFERENCE_NUMBER: ', IFNULL(GUARANTEE_REFERENCE_NUMBER,                       '(NULL)'), 
            '\n    GUARANTEE_INTERNAL_REFERENCE: ', IFNULL(GUARANTEE_INTERNAL_REFERENCE,                     '(NULL)'), 
            '\n               REASON_FOR_CHANGE: ', IFNULL(REASON_FOR_CHANGE,                                '(NULL)'))
        Into p_result_o
        From guarantee_limit
        Where GUARANTEE_LIMIT_ID = p_guaranteeLimitID_i;
        IF p_result_o is null THEN
            Set p_result_o = CONCAT(
                'Success reported, but the modified ''guarantee_limit'' record (GUARANTEE_LIMIT_ID ', 
                p_guaranteeLimitID_i, ') could not be read back.'
            );
        END IF;
    END IF;
END ;;
