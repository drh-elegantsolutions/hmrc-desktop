/**
 * ETMP_TransactionDutyDefermentDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_TransactionDutyDefermentDetails  implements java.io.Serializable {
    private java.lang.String EORI;

    private java.lang.String DAN;

    private java.lang.String reasonForAmendment;

    private java.lang.String dutyDefermentAccountName;

    private boolean removeDutyDfrmntAcntName;

    private java.util.Date changeDANStartDate;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails;

    private boolean removeBankIndicator;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails[] DGLDetails;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails[] DALDetails;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses;

    private boolean removeCorspdncAddrs;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations;

    public ETMP_TransactionDutyDefermentDetails() {
    }

    public ETMP_TransactionDutyDefermentDetails(
           java.lang.String EORI,
           java.lang.String DAN,
           java.lang.String reasonForAmendment,
           java.lang.String dutyDefermentAccountName,
           boolean removeDutyDfrmntAcntName,
           java.util.Date changeDANStartDate,
           uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails,
           boolean removeBankIndicator,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails[] DGLDetails,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails[] DALDetails,
           uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses,
           boolean removeCorspdncAddrs,
           uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations) {
           this.EORI = EORI;
           this.DAN = DAN;
           this.reasonForAmendment = reasonForAmendment;
           this.dutyDefermentAccountName = dutyDefermentAccountName;
           this.removeDutyDfrmntAcntName = removeDutyDfrmntAcntName;
           this.changeDANStartDate = changeDANStartDate;
           this.dutyDefermentStatus = dutyDefermentStatus;
           this.bankDetails = bankDetails;
           this.removeBankIndicator = removeBankIndicator;
           this.DGLDetails = DGLDetails;
           this.DALDetails = DALDetails;
           this.correspondenceAddresses = correspondenceAddresses;
           this.removeCorspdncAddrs = removeCorspdncAddrs;
           this.authorisations = authorisations;
    }


    /**
     * Gets the EORI value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return EORI
     */
    public java.lang.String getEORI() {
        return EORI;
    }


    /**
     * Sets the EORI value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param EORI
     */
    public void setEORI(java.lang.String EORI) {
        this.EORI = EORI;
    }


    /**
     * Gets the DAN value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return DAN
     */
    public java.lang.String getDAN() {
        return DAN;
    }


    /**
     * Sets the DAN value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param DAN
     */
    public void setDAN(java.lang.String DAN) {
        this.DAN = DAN;
    }


    /**
     * Gets the reasonForAmendment value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return reasonForAmendment
     */
    public java.lang.String getReasonForAmendment() {
        return reasonForAmendment;
    }


    /**
     * Sets the reasonForAmendment value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param reasonForAmendment
     */
    public void setReasonForAmendment(java.lang.String reasonForAmendment) {
        this.reasonForAmendment = reasonForAmendment;
    }


    /**
     * Gets the dutyDefermentAccountName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return dutyDefermentAccountName
     */
    public java.lang.String getDutyDefermentAccountName() {
        return dutyDefermentAccountName;
    }


    /**
     * Sets the dutyDefermentAccountName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param dutyDefermentAccountName
     */
    public void setDutyDefermentAccountName(java.lang.String dutyDefermentAccountName) {
        this.dutyDefermentAccountName = dutyDefermentAccountName;
    }


    /**
     * Gets the removeDutyDfrmntAcntName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return removeDutyDfrmntAcntName
     */
    public boolean isRemoveDutyDfrmntAcntName() {
        return removeDutyDfrmntAcntName;
    }


    /**
     * Sets the removeDutyDfrmntAcntName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param removeDutyDfrmntAcntName
     */
    public void setRemoveDutyDfrmntAcntName(boolean removeDutyDfrmntAcntName) {
        this.removeDutyDfrmntAcntName = removeDutyDfrmntAcntName;
    }


    /**
     * Gets the changeDANStartDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return changeDANStartDate
     */
    public java.util.Date getChangeDANStartDate() {
        return changeDANStartDate;
    }


    /**
     * Sets the changeDANStartDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param changeDANStartDate
     */
    public void setChangeDANStartDate(java.util.Date changeDANStartDate) {
        this.changeDANStartDate = changeDANStartDate;
    }


    /**
     * Gets the dutyDefermentStatus value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return dutyDefermentStatus
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType getDutyDefermentStatus() {
        return dutyDefermentStatus;
    }


    /**
     * Sets the dutyDefermentStatus value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param dutyDefermentStatus
     */
    public void setDutyDefermentStatus(uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus) {
        this.dutyDefermentStatus = dutyDefermentStatus;
    }


    /**
     * Gets the bankDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return bankDetails
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails getBankDetails() {
        return bankDetails;
    }


    /**
     * Sets the bankDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param bankDetails
     */
    public void setBankDetails(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails) {
        this.bankDetails = bankDetails;
    }


    /**
     * Gets the removeBankIndicator value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return removeBankIndicator
     */
    public boolean isRemoveBankIndicator() {
        return removeBankIndicator;
    }


    /**
     * Sets the removeBankIndicator value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param removeBankIndicator
     */
    public void setRemoveBankIndicator(boolean removeBankIndicator) {
        this.removeBankIndicator = removeBankIndicator;
    }


    /**
     * Gets the DGLDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return DGLDetails
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails[] getDGLDetails() {
        return DGLDetails;
    }


    /**
     * Sets the DGLDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param DGLDetails
     */
    public void setDGLDetails(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails[] DGLDetails) {
        this.DGLDetails = DGLDetails;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails getDGLDetails(int i) {
        return this.DGLDetails[i];
    }

    public void setDGLDetails(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDGLDetails _value) {
        this.DGLDetails[i] = _value;
    }


    /**
     * Gets the DALDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return DALDetails
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails[] getDALDetails() {
        return DALDetails;
    }


    /**
     * Sets the DALDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param DALDetails
     */
    public void setDALDetails(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails[] DALDetails) {
        this.DALDetails = DALDetails;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails getDALDetails(int i) {
        return this.DALDetails[i];
    }

    public void setDALDetails(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetails _value) {
        this.DALDetails[i] = _value;
    }


    /**
     * Gets the correspondenceAddresses value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return correspondenceAddresses
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType getCorrespondenceAddresses() {
        return correspondenceAddresses;
    }


    /**
     * Sets the correspondenceAddresses value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param correspondenceAddresses
     */
    public void setCorrespondenceAddresses(uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses) {
        this.correspondenceAddresses = correspondenceAddresses;
    }


    /**
     * Gets the removeCorspdncAddrs value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return removeCorspdncAddrs
     */
    public boolean isRemoveCorspdncAddrs() {
        return removeCorspdncAddrs;
    }


    /**
     * Sets the removeCorspdncAddrs value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param removeCorspdncAddrs
     */
    public void setRemoveCorspdncAddrs(boolean removeCorspdncAddrs) {
        this.removeCorspdncAddrs = removeCorspdncAddrs;
    }


    /**
     * Gets the authorisations value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return authorisations
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] getAuthorisations() {
        return authorisations;
    }


    /**
     * Sets the authorisations value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param authorisations
     */
    public void setAuthorisations(uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations) {
        this.authorisations = authorisations;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType getAuthorisations(int i) {
        return this.authorisations[i];
    }

    public void setAuthorisations(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType _value) {
        this.authorisations[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_TransactionDutyDefermentDetails)) return false;
        ETMP_TransactionDutyDefermentDetails other = (ETMP_TransactionDutyDefermentDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.EORI==null && other.getEORI()==null) || 
             (this.EORI!=null &&
              this.EORI.equals(other.getEORI()))) &&
            ((this.DAN==null && other.getDAN()==null) || 
             (this.DAN!=null &&
              this.DAN.equals(other.getDAN()))) &&
            ((this.reasonForAmendment==null && other.getReasonForAmendment()==null) || 
             (this.reasonForAmendment!=null &&
              this.reasonForAmendment.equals(other.getReasonForAmendment()))) &&
            ((this.dutyDefermentAccountName==null && other.getDutyDefermentAccountName()==null) || 
             (this.dutyDefermentAccountName!=null &&
              this.dutyDefermentAccountName.equals(other.getDutyDefermentAccountName()))) &&
            this.removeDutyDfrmntAcntName == other.isRemoveDutyDfrmntAcntName() &&
            ((this.changeDANStartDate==null && other.getChangeDANStartDate()==null) || 
             (this.changeDANStartDate!=null &&
              this.changeDANStartDate.equals(other.getChangeDANStartDate()))) &&
            ((this.dutyDefermentStatus==null && other.getDutyDefermentStatus()==null) || 
             (this.dutyDefermentStatus!=null &&
              this.dutyDefermentStatus.equals(other.getDutyDefermentStatus()))) &&
            ((this.bankDetails==null && other.getBankDetails()==null) || 
             (this.bankDetails!=null &&
              this.bankDetails.equals(other.getBankDetails()))) &&
            this.removeBankIndicator == other.isRemoveBankIndicator() &&
            ((this.DGLDetails==null && other.getDGLDetails()==null) || 
             (this.DGLDetails!=null &&
              java.util.Arrays.equals(this.DGLDetails, other.getDGLDetails()))) &&
            ((this.DALDetails==null && other.getDALDetails()==null) || 
             (this.DALDetails!=null &&
              java.util.Arrays.equals(this.DALDetails, other.getDALDetails()))) &&
            ((this.correspondenceAddresses==null && other.getCorrespondenceAddresses()==null) || 
             (this.correspondenceAddresses!=null &&
              this.correspondenceAddresses.equals(other.getCorrespondenceAddresses()))) &&
            this.removeCorspdncAddrs == other.isRemoveCorspdncAddrs() &&
            ((this.authorisations==null && other.getAuthorisations()==null) || 
             (this.authorisations!=null &&
              java.util.Arrays.equals(this.authorisations, other.getAuthorisations())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEORI() != null) {
            _hashCode += getEORI().hashCode();
        }
        if (getDAN() != null) {
            _hashCode += getDAN().hashCode();
        }
        if (getReasonForAmendment() != null) {
            _hashCode += getReasonForAmendment().hashCode();
        }
        if (getDutyDefermentAccountName() != null) {
            _hashCode += getDutyDefermentAccountName().hashCode();
        }
        _hashCode += (isRemoveDutyDfrmntAcntName() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getChangeDANStartDate() != null) {
            _hashCode += getChangeDANStartDate().hashCode();
        }
        if (getDutyDefermentStatus() != null) {
            _hashCode += getDutyDefermentStatus().hashCode();
        }
        if (getBankDetails() != null) {
            _hashCode += getBankDetails().hashCode();
        }
        _hashCode += (isRemoveBankIndicator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getDGLDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDGLDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDGLDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDALDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDALDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDALDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCorrespondenceAddresses() != null) {
            _hashCode += getCorrespondenceAddresses().hashCode();
        }
        _hashCode += (isRemoveCorspdncAddrs() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getAuthorisations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthorisations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthorisations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_TransactionDutyDefermentDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction>DutyDefermentDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EORI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EORI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DAN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reasonForAmendment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ReasonForAmendment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentAccountName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentAccountName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("removeDutyDfrmntAcntName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "RemoveDutyDfrmntAcntName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeDANStartDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ChangeDANStartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "BankDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>BankDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("removeBankIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "RemoveBankIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DGLDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DGLDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>DGLDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DALDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DALDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>DALDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondenceAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "CorrespondenceAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("removeCorspdncAddrs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "RemoveCorspdncAddrs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Authorisations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AuthorisationsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
