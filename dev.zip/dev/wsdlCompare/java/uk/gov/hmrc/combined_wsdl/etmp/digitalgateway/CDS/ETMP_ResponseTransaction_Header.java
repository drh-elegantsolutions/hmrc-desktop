/**
 * ETMP_ResponseTransaction_Header.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_ResponseTransaction_Header  implements java.io.Serializable {
    /* Possible values are 
     *       OK
     *       NOT_OK */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderStatus status;

    /* Status Text */
    private java.lang.String statusText;

    /* The date the message was processed */
    private java.util.Calendar processingDate;

    /* Return Parameters */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters[] returnParameters;

    public ETMP_ResponseTransaction_Header() {
    }

    public ETMP_ResponseTransaction_Header(
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderStatus status,
           java.lang.String statusText,
           java.util.Calendar processingDate,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters[] returnParameters) {
           this.status = status;
           this.statusText = statusText;
           this.processingDate = processingDate;
           this.returnParameters = returnParameters;
    }


    /**
     * Gets the status value for this ETMP_ResponseTransaction_Header.
     * 
     * @return status   * Possible values are 
     *       OK
     *       NOT_OK
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderStatus getStatus() {
        return status;
    }


    /**
     * Sets the status value for this ETMP_ResponseTransaction_Header.
     * 
     * @param status   * Possible values are 
     *       OK
     *       NOT_OK
     */
    public void setStatus(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderStatus status) {
        this.status = status;
    }


    /**
     * Gets the statusText value for this ETMP_ResponseTransaction_Header.
     * 
     * @return statusText   * Status Text
     */
    public java.lang.String getStatusText() {
        return statusText;
    }


    /**
     * Sets the statusText value for this ETMP_ResponseTransaction_Header.
     * 
     * @param statusText   * Status Text
     */
    public void setStatusText(java.lang.String statusText) {
        this.statusText = statusText;
    }


    /**
     * Gets the processingDate value for this ETMP_ResponseTransaction_Header.
     * 
     * @return processingDate   * The date the message was processed
     */
    public java.util.Calendar getProcessingDate() {
        return processingDate;
    }


    /**
     * Sets the processingDate value for this ETMP_ResponseTransaction_Header.
     * 
     * @param processingDate   * The date the message was processed
     */
    public void setProcessingDate(java.util.Calendar processingDate) {
        this.processingDate = processingDate;
    }


    /**
     * Gets the returnParameters value for this ETMP_ResponseTransaction_Header.
     * 
     * @return returnParameters   * Return Parameters
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters[] getReturnParameters() {
        return returnParameters;
    }


    /**
     * Sets the returnParameters value for this ETMP_ResponseTransaction_Header.
     * 
     * @param returnParameters   * Return Parameters
     */
    public void setReturnParameters(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters[] returnParameters) {
        this.returnParameters = returnParameters;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters getReturnParameters(int i) {
        return this.returnParameters[i];
    }

    public void setReturnParameters(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParameters _value) {
        this.returnParameters[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_ResponseTransaction_Header)) return false;
        ETMP_ResponseTransaction_Header other = (ETMP_ResponseTransaction_Header) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.statusText==null && other.getStatusText()==null) || 
             (this.statusText!=null &&
              this.statusText.equals(other.getStatusText()))) &&
            ((this.processingDate==null && other.getProcessingDate()==null) || 
             (this.processingDate!=null &&
              this.processingDate.equals(other.getProcessingDate()))) &&
            ((this.returnParameters==null && other.getReturnParameters()==null) || 
             (this.returnParameters!=null &&
              java.util.Arrays.equals(this.returnParameters, other.getReturnParameters())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getStatusText() != null) {
            _hashCode += getStatusText().hashCode();
        }
        if (getProcessingDate() != null) {
            _hashCode += getProcessingDate().hashCode();
        }
        if (getReturnParameters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getReturnParameters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getReturnParameters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_ResponseTransaction_Header.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ETMP_ResponseTransaction_Header"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_ResponseTransaction_Header>Status"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "StatusText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processingDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ProcessingDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ReturnParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_ResponseTransaction_Header>ReturnParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
