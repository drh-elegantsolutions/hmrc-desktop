package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class DutyDefermentDisplaySyncProxy implements uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentDisplaySync {
  private String _endpoint = null;
  private uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentDisplaySync dutyDefermentDisplaySync = null;
  
  public DutyDefermentDisplaySyncProxy() {
    _initDutyDefermentDisplaySyncProxy();
  }
  
  public DutyDefermentDisplaySyncProxy(String endpoint) {
    _endpoint = endpoint;
    _initDutyDefermentDisplaySyncProxy();
  }
  
  private void _initDutyDefermentDisplaySyncProxy() {
    try {
      dutyDefermentDisplaySync = (new uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentDisplaySyncServiceLocator()).getHTTPS_Port();
      if (dutyDefermentDisplaySync != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dutyDefermentDisplaySync != null)
      ((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentDisplaySync getDutyDefermentDisplaySync() {
    if (dutyDefermentDisplaySync == null)
      _initDutyDefermentDisplaySyncProxy();
    return dutyDefermentDisplaySync;
  }
  
  public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Response dutyDefermentDisplaySync(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction ETMP_Transaction) throws java.rmi.RemoteException, uk.gov.hmrc.etmp.digitalgateway.CDS.StandardMessageFault{
    if (dutyDefermentDisplaySync == null)
      _initDutyDefermentDisplaySyncProxy();
    return dutyDefermentDisplaySync.dutyDefermentDisplaySync(ETMP_Transaction);
  }
  
  
}