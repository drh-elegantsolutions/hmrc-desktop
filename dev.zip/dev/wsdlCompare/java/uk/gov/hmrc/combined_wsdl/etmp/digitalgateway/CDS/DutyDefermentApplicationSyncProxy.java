package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class DutyDefermentApplicationSyncProxy implements uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentApplicationSync {
  private String _endpoint = null;
  private uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentApplicationSync dutyDefermentApplicationSync = null;
  
  public DutyDefermentApplicationSyncProxy() {
    _initDutyDefermentApplicationSyncProxy();
  }
  
  public DutyDefermentApplicationSyncProxy(String endpoint) {
    _endpoint = endpoint;
    _initDutyDefermentApplicationSyncProxy();
  }
  
  private void _initDutyDefermentApplicationSyncProxy() {
    try {
      dutyDefermentApplicationSync = (new uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentApplicationSyncServiceLocator()).getHTTPS_Port();
      if (dutyDefermentApplicationSync != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dutyDefermentApplicationSync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dutyDefermentApplicationSync)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dutyDefermentApplicationSync != null)
      ((javax.xml.rpc.Stub)dutyDefermentApplicationSync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentApplicationSync getDutyDefermentApplicationSync() {
    if (dutyDefermentApplicationSync == null)
      _initDutyDefermentApplicationSyncProxy();
    return dutyDefermentApplicationSync;
  }
  
  public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_Header dutyDefermentApplicationSync(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction ETMP_Transaction) throws java.rmi.RemoteException, uk.gov.hmrc.etmp.digitalgateway.CDS.StandardMessageFault{
    if (dutyDefermentApplicationSync == null)
      _initDutyDefermentApplicationSyncProxy();
    return dutyDefermentApplicationSync.dutyDefermentApplicationSync(ETMP_Transaction);
  }
  
  
}