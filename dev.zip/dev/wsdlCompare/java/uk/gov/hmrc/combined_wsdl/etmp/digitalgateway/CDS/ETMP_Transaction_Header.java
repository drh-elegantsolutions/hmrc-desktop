/**
 * ETMP_Transaction_Header.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_Transaction_Header  implements java.io.Serializable {
    /* Name or IP Address of the system sending the message to PI */
    private java.lang.String transmittingSystem;

    /* Name or IP address of the application system that submitted
     * the message */
    private java.lang.String originatingSystem;

    /* The time the message was created by the system sending the
     * message. */
    private java.util.Calendar receiptDate;

    /* Unique id created at source after a form is saved. Unique ID
     * though out the jouney of a message -- stored in ETMP data records,
     * passed to decision service, ETMP records can be searched using this
     * field  etc. */
    private java.lang.String acknowledgementReference;

    /* One Message Type. */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_HeaderMessageTypes messageTypes;

    public ETMP_Transaction_Header() {
    }

    public ETMP_Transaction_Header(
           java.lang.String transmittingSystem,
           java.lang.String originatingSystem,
           java.util.Calendar receiptDate,
           java.lang.String acknowledgementReference,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_HeaderMessageTypes messageTypes) {
           this.transmittingSystem = transmittingSystem;
           this.originatingSystem = originatingSystem;
           this.receiptDate = receiptDate;
           this.acknowledgementReference = acknowledgementReference;
           this.messageTypes = messageTypes;
    }


    /**
     * Gets the transmittingSystem value for this ETMP_Transaction_Header.
     * 
     * @return transmittingSystem   * Name or IP Address of the system sending the message to PI
     */
    public java.lang.String getTransmittingSystem() {
        return transmittingSystem;
    }


    /**
     * Sets the transmittingSystem value for this ETMP_Transaction_Header.
     * 
     * @param transmittingSystem   * Name or IP Address of the system sending the message to PI
     */
    public void setTransmittingSystem(java.lang.String transmittingSystem) {
        this.transmittingSystem = transmittingSystem;
    }


    /**
     * Gets the originatingSystem value for this ETMP_Transaction_Header.
     * 
     * @return originatingSystem   * Name or IP address of the application system that submitted
     * the message
     */
    public java.lang.String getOriginatingSystem() {
        return originatingSystem;
    }


    /**
     * Sets the originatingSystem value for this ETMP_Transaction_Header.
     * 
     * @param originatingSystem   * Name or IP address of the application system that submitted
     * the message
     */
    public void setOriginatingSystem(java.lang.String originatingSystem) {
        this.originatingSystem = originatingSystem;
    }


    /**
     * Gets the receiptDate value for this ETMP_Transaction_Header.
     * 
     * @return receiptDate   * The time the message was created by the system sending the
     * message.
     */
    public java.util.Calendar getReceiptDate() {
        return receiptDate;
    }


    /**
     * Sets the receiptDate value for this ETMP_Transaction_Header.
     * 
     * @param receiptDate   * The time the message was created by the system sending the
     * message.
     */
    public void setReceiptDate(java.util.Calendar receiptDate) {
        this.receiptDate = receiptDate;
    }


    /**
     * Gets the acknowledgementReference value for this ETMP_Transaction_Header.
     * 
     * @return acknowledgementReference   * Unique id created at source after a form is saved. Unique ID
     * though out the jouney of a message -- stored in ETMP data records,
     * passed to decision service, ETMP records can be searched using this
     * field  etc.
     */
    public java.lang.String getAcknowledgementReference() {
        return acknowledgementReference;
    }


    /**
     * Sets the acknowledgementReference value for this ETMP_Transaction_Header.
     * 
     * @param acknowledgementReference   * Unique id created at source after a form is saved. Unique ID
     * though out the jouney of a message -- stored in ETMP data records,
     * passed to decision service, ETMP records can be searched using this
     * field  etc.
     */
    public void setAcknowledgementReference(java.lang.String acknowledgementReference) {
        this.acknowledgementReference = acknowledgementReference;
    }


    /**
     * Gets the messageTypes value for this ETMP_Transaction_Header.
     * 
     * @return messageTypes   * One Message Type.
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_HeaderMessageTypes getMessageTypes() {
        return messageTypes;
    }


    /**
     * Sets the messageTypes value for this ETMP_Transaction_Header.
     * 
     * @param messageTypes   * One Message Type.
     */
    public void setMessageTypes(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_HeaderMessageTypes messageTypes) {
        this.messageTypes = messageTypes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction_Header)) return false;
        ETMP_Transaction_Header other = (ETMP_Transaction_Header) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transmittingSystem==null && other.getTransmittingSystem()==null) || 
             (this.transmittingSystem!=null &&
              this.transmittingSystem.equals(other.getTransmittingSystem()))) &&
            ((this.originatingSystem==null && other.getOriginatingSystem()==null) || 
             (this.originatingSystem!=null &&
              this.originatingSystem.equals(other.getOriginatingSystem()))) &&
            ((this.receiptDate==null && other.getReceiptDate()==null) || 
             (this.receiptDate!=null &&
              this.receiptDate.equals(other.getReceiptDate()))) &&
            ((this.acknowledgementReference==null && other.getAcknowledgementReference()==null) || 
             (this.acknowledgementReference!=null &&
              this.acknowledgementReference.equals(other.getAcknowledgementReference()))) &&
            ((this.messageTypes==null && other.getMessageTypes()==null) || 
             (this.messageTypes!=null &&
              this.messageTypes.equals(other.getMessageTypes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransmittingSystem() != null) {
            _hashCode += getTransmittingSystem().hashCode();
        }
        if (getOriginatingSystem() != null) {
            _hashCode += getOriginatingSystem().hashCode();
        }
        if (getReceiptDate() != null) {
            _hashCode += getReceiptDate().hashCode();
        }
        if (getAcknowledgementReference() != null) {
            _hashCode += getAcknowledgementReference().hashCode();
        }
        if (getMessageTypes() != null) {
            _hashCode += getMessageTypes().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction_Header.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction_Header"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transmittingSystem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "TransmittingSystem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("originatingSystem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "OriginatingSystem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiptDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ReceiptDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acknowledgementReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AcknowledgementReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "MessageTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction_Header>MessageTypes"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
