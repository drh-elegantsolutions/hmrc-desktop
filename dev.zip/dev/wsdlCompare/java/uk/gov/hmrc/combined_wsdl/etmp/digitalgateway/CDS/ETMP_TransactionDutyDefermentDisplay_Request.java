/**
 * ETMP_TransactionDutyDefermentDisplay_Request.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_TransactionDutyDefermentDisplay_Request  implements java.io.Serializable {
    private java.lang.String EORI;

    private java.lang.String DAN;

    private java.util.Date detailsValidFromDate;

    public ETMP_TransactionDutyDefermentDisplay_Request() {
    }

    public ETMP_TransactionDutyDefermentDisplay_Request(
           java.lang.String EORI,
           java.lang.String DAN,
           java.util.Date detailsValidFromDate) {
           this.EORI = EORI;
           this.DAN = DAN;
           this.detailsValidFromDate = detailsValidFromDate;
    }


    /**
     * Gets the EORI value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @return EORI
     */
    public java.lang.String getEORI() {
        return EORI;
    }


    /**
     * Sets the EORI value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @param EORI
     */
    public void setEORI(java.lang.String EORI) {
        this.EORI = EORI;
    }


    /**
     * Gets the DAN value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @return DAN
     */
    public java.lang.String getDAN() {
        return DAN;
    }


    /**
     * Sets the DAN value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @param DAN
     */
    public void setDAN(java.lang.String DAN) {
        this.DAN = DAN;
    }


    /**
     * Gets the detailsValidFromDate value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @return detailsValidFromDate
     */
    public java.util.Date getDetailsValidFromDate() {
        return detailsValidFromDate;
    }


    /**
     * Sets the detailsValidFromDate value for this ETMP_TransactionDutyDefermentDisplay_Request.
     * 
     * @param detailsValidFromDate
     */
    public void setDetailsValidFromDate(java.util.Date detailsValidFromDate) {
        this.detailsValidFromDate = detailsValidFromDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_TransactionDutyDefermentDisplay_Request)) return false;
        ETMP_TransactionDutyDefermentDisplay_Request other = (ETMP_TransactionDutyDefermentDisplay_Request) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.EORI==null && other.getEORI()==null) || 
             (this.EORI!=null &&
              this.EORI.equals(other.getEORI()))) &&
            ((this.DAN==null && other.getDAN()==null) || 
             (this.DAN!=null &&
              this.DAN.equals(other.getDAN()))) &&
            ((this.detailsValidFromDate==null && other.getDetailsValidFromDate()==null) || 
             (this.detailsValidFromDate!=null &&
              this.detailsValidFromDate.equals(other.getDetailsValidFromDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEORI() != null) {
            _hashCode += getEORI().hashCode();
        }
        if (getDAN() != null) {
            _hashCode += getDAN().hashCode();
        }
        if (getDetailsValidFromDate() != null) {
            _hashCode += getDetailsValidFromDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_TransactionDutyDefermentDisplay_Request.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction>DutyDefermentDisplay_Request"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EORI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EORI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DAN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detailsValidFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DetailsValidFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
