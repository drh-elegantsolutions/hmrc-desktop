/**
 * ETMP_TransactionDutyDefermentDetailsDALDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_TransactionDutyDefermentDetailsDALDetails  implements java.io.Serializable {
    private java.math.BigDecimal defermentAccountLimit;

    private java.util.Date effectiveFromDate;

    /* 1 - Add Account Limit
     * 2 - Adjust Account Limit
     * 3 - Remove Account Limit */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetailsActionType actionType;

    public ETMP_TransactionDutyDefermentDetailsDALDetails() {
    }

    public ETMP_TransactionDutyDefermentDetailsDALDetails(
           java.math.BigDecimal defermentAccountLimit,
           java.util.Date effectiveFromDate,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetailsActionType actionType) {
           this.defermentAccountLimit = defermentAccountLimit;
           this.effectiveFromDate = effectiveFromDate;
           this.actionType = actionType;
    }


    /**
     * Gets the defermentAccountLimit value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @return defermentAccountLimit
     */
    public java.math.BigDecimal getDefermentAccountLimit() {
        return defermentAccountLimit;
    }


    /**
     * Sets the defermentAccountLimit value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @param defermentAccountLimit
     */
    public void setDefermentAccountLimit(java.math.BigDecimal defermentAccountLimit) {
        this.defermentAccountLimit = defermentAccountLimit;
    }


    /**
     * Gets the effectiveFromDate value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @return effectiveFromDate
     */
    public java.util.Date getEffectiveFromDate() {
        return effectiveFromDate;
    }


    /**
     * Sets the effectiveFromDate value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @param effectiveFromDate
     */
    public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }


    /**
     * Gets the actionType value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @return actionType   * 1 - Add Account Limit
     * 2 - Adjust Account Limit
     * 3 - Remove Account Limit
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetailsActionType getActionType() {
        return actionType;
    }


    /**
     * Sets the actionType value for this ETMP_TransactionDutyDefermentDetailsDALDetails.
     * 
     * @param actionType   * 1 - Add Account Limit
     * 2 - Adjust Account Limit
     * 3 - Remove Account Limit
     */
    public void setActionType(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsDALDetailsActionType actionType) {
        this.actionType = actionType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_TransactionDutyDefermentDetailsDALDetails)) return false;
        ETMP_TransactionDutyDefermentDetailsDALDetails other = (ETMP_TransactionDutyDefermentDetailsDALDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.defermentAccountLimit==null && other.getDefermentAccountLimit()==null) || 
             (this.defermentAccountLimit!=null &&
              this.defermentAccountLimit.equals(other.getDefermentAccountLimit()))) &&
            ((this.effectiveFromDate==null && other.getEffectiveFromDate()==null) || 
             (this.effectiveFromDate!=null &&
              this.effectiveFromDate.equals(other.getEffectiveFromDate()))) &&
            ((this.actionType==null && other.getActionType()==null) || 
             (this.actionType!=null &&
              this.actionType.equals(other.getActionType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDefermentAccountLimit() != null) {
            _hashCode += getDefermentAccountLimit().hashCode();
        }
        if (getEffectiveFromDate() != null) {
            _hashCode += getEffectiveFromDate().hashCode();
        }
        if (getActionType() != null) {
            _hashCode += getActionType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_TransactionDutyDefermentDetailsDALDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>DALDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defermentAccountLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DefermentAccountLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ActionType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>>ETMP_Transaction>DutyDefermentDetails>DALDetails>ActionType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
