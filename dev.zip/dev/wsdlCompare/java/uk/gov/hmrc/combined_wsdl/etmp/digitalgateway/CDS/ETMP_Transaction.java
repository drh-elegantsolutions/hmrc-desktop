/**
 * ETMP_Transaction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_Transaction  implements java.io.Serializable {
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Header ETMP_Transaction_Header;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDisplay_Request dutyDefermentDisplay_Request;

    public ETMP_Transaction() {
    }

    public ETMP_Transaction(
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Header ETMP_Transaction_Header,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDisplay_Request dutyDefermentDisplay_Request) {
           this.ETMP_Transaction_Header = ETMP_Transaction_Header;
           this.dutyDefermentDisplay_Request = dutyDefermentDisplay_Request;
    }


    /**
     * Gets the ETMP_Transaction_Header value for this ETMP_Transaction.
     * 
     * @return ETMP_Transaction_Header
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Header getETMP_Transaction_Header() {
        return ETMP_Transaction_Header;
    }


    /**
     * Sets the ETMP_Transaction_Header value for this ETMP_Transaction.
     * 
     * @param ETMP_Transaction_Header
     */
    public void setETMP_Transaction_Header(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_Header ETMP_Transaction_Header) {
        this.ETMP_Transaction_Header = ETMP_Transaction_Header;
    }


    /**
     * Gets the dutyDefermentDisplay_Request value for this ETMP_Transaction.
     * 
     * @return dutyDefermentDisplay_Request
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDisplay_Request getDutyDefermentDisplay_Request() {
        return dutyDefermentDisplay_Request;
    }


    /**
     * Sets the dutyDefermentDisplay_Request value for this ETMP_Transaction.
     * 
     * @param dutyDefermentDisplay_Request
     */
    public void setDutyDefermentDisplay_Request(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDisplay_Request dutyDefermentDisplay_Request) {
        this.dutyDefermentDisplay_Request = dutyDefermentDisplay_Request;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction)) return false;
        ETMP_Transaction other = (ETMP_Transaction) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ETMP_Transaction_Header==null && other.getETMP_Transaction_Header()==null) || 
             (this.ETMP_Transaction_Header!=null &&
              this.ETMP_Transaction_Header.equals(other.getETMP_Transaction_Header()))) &&
            ((this.dutyDefermentDisplay_Request==null && other.getDutyDefermentDisplay_Request()==null) || 
             (this.dutyDefermentDisplay_Request!=null &&
              this.dutyDefermentDisplay_Request.equals(other.getDutyDefermentDisplay_Request())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getETMP_Transaction_Header() != null) {
            _hashCode += getETMP_Transaction_Header().hashCode();
        }
        if (getDutyDefermentDisplay_Request() != null) {
            _hashCode += getDutyDefermentDisplay_Request().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ETMP_Transaction_Header");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ETMP_Transaction_Header"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction_Header"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentDisplay_Request");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentDisplay_Request"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction>DutyDefermentDisplay_Request"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
