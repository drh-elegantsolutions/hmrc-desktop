/**
 * ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails  implements java.io.Serializable {
    /* Possible values:
     * TG - Temporary Guarantee
     * PG - Permanent Guarantee */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetailsGuaranteeCategory guaranteeCategory;

    private java.lang.String guaranteeInternalReference;

    private java.lang.String guaranteeReferenceNumber;

    private java.math.BigDecimal guaranteeAmount;

    private java.lang.String guarantorID;

    private java.util.Date effectiveFromDate;

    private java.util.Date effectiveToDate;

    public ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails() {
    }

    public ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails(
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetailsGuaranteeCategory guaranteeCategory,
           java.lang.String guaranteeInternalReference,
           java.lang.String guaranteeReferenceNumber,
           java.math.BigDecimal guaranteeAmount,
           java.lang.String guarantorID,
           java.util.Date effectiveFromDate,
           java.util.Date effectiveToDate) {
           this.guaranteeCategory = guaranteeCategory;
           this.guaranteeInternalReference = guaranteeInternalReference;
           this.guaranteeReferenceNumber = guaranteeReferenceNumber;
           this.guaranteeAmount = guaranteeAmount;
           this.guarantorID = guarantorID;
           this.effectiveFromDate = effectiveFromDate;
           this.effectiveToDate = effectiveToDate;
    }


    /**
     * Gets the guaranteeCategory value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return guaranteeCategory   * Possible values:
     * TG - Temporary Guarantee
     * PG - Permanent Guarantee
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetailsGuaranteeCategory getGuaranteeCategory() {
        return guaranteeCategory;
    }


    /**
     * Sets the guaranteeCategory value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param guaranteeCategory   * Possible values:
     * TG - Temporary Guarantee
     * PG - Permanent Guarantee
     */
    public void setGuaranteeCategory(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetailsGuaranteeCategory guaranteeCategory) {
        this.guaranteeCategory = guaranteeCategory;
    }


    /**
     * Gets the guaranteeInternalReference value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return guaranteeInternalReference
     */
    public java.lang.String getGuaranteeInternalReference() {
        return guaranteeInternalReference;
    }


    /**
     * Sets the guaranteeInternalReference value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param guaranteeInternalReference
     */
    public void setGuaranteeInternalReference(java.lang.String guaranteeInternalReference) {
        this.guaranteeInternalReference = guaranteeInternalReference;
    }


    /**
     * Gets the guaranteeReferenceNumber value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return guaranteeReferenceNumber
     */
    public java.lang.String getGuaranteeReferenceNumber() {
        return guaranteeReferenceNumber;
    }


    /**
     * Sets the guaranteeReferenceNumber value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param guaranteeReferenceNumber
     */
    public void setGuaranteeReferenceNumber(java.lang.String guaranteeReferenceNumber) {
        this.guaranteeReferenceNumber = guaranteeReferenceNumber;
    }


    /**
     * Gets the guaranteeAmount value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return guaranteeAmount
     */
    public java.math.BigDecimal getGuaranteeAmount() {
        return guaranteeAmount;
    }


    /**
     * Sets the guaranteeAmount value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param guaranteeAmount
     */
    public void setGuaranteeAmount(java.math.BigDecimal guaranteeAmount) {
        this.guaranteeAmount = guaranteeAmount;
    }


    /**
     * Gets the guarantorID value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return guarantorID
     */
    public java.lang.String getGuarantorID() {
        return guarantorID;
    }


    /**
     * Sets the guarantorID value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param guarantorID
     */
    public void setGuarantorID(java.lang.String guarantorID) {
        this.guarantorID = guarantorID;
    }


    /**
     * Gets the effectiveFromDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return effectiveFromDate
     */
    public java.util.Date getEffectiveFromDate() {
        return effectiveFromDate;
    }


    /**
     * Sets the effectiveFromDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param effectiveFromDate
     */
    public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }


    /**
     * Gets the effectiveToDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @return effectiveToDate
     */
    public java.util.Date getEffectiveToDate() {
        return effectiveToDate;
    }


    /**
     * Sets the effectiveToDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.
     * 
     * @param effectiveToDate
     */
    public void setEffectiveToDate(java.util.Date effectiveToDate) {
        this.effectiveToDate = effectiveToDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails)) return false;
        ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails other = (ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.guaranteeCategory==null && other.getGuaranteeCategory()==null) || 
             (this.guaranteeCategory!=null &&
              this.guaranteeCategory.equals(other.getGuaranteeCategory()))) &&
            ((this.guaranteeInternalReference==null && other.getGuaranteeInternalReference()==null) || 
             (this.guaranteeInternalReference!=null &&
              this.guaranteeInternalReference.equals(other.getGuaranteeInternalReference()))) &&
            ((this.guaranteeReferenceNumber==null && other.getGuaranteeReferenceNumber()==null) || 
             (this.guaranteeReferenceNumber!=null &&
              this.guaranteeReferenceNumber.equals(other.getGuaranteeReferenceNumber()))) &&
            ((this.guaranteeAmount==null && other.getGuaranteeAmount()==null) || 
             (this.guaranteeAmount!=null &&
              this.guaranteeAmount.equals(other.getGuaranteeAmount()))) &&
            ((this.guarantorID==null && other.getGuarantorID()==null) || 
             (this.guarantorID!=null &&
              this.guarantorID.equals(other.getGuarantorID()))) &&
            ((this.effectiveFromDate==null && other.getEffectiveFromDate()==null) || 
             (this.effectiveFromDate!=null &&
              this.effectiveFromDate.equals(other.getEffectiveFromDate()))) &&
            ((this.effectiveToDate==null && other.getEffectiveToDate()==null) || 
             (this.effectiveToDate!=null &&
              this.effectiveToDate.equals(other.getEffectiveToDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGuaranteeCategory() != null) {
            _hashCode += getGuaranteeCategory().hashCode();
        }
        if (getGuaranteeInternalReference() != null) {
            _hashCode += getGuaranteeInternalReference().hashCode();
        }
        if (getGuaranteeReferenceNumber() != null) {
            _hashCode += getGuaranteeReferenceNumber().hashCode();
        }
        if (getGuaranteeAmount() != null) {
            _hashCode += getGuaranteeAmount().hashCode();
        }
        if (getGuarantorID() != null) {
            _hashCode += getGuarantorID().hashCode();
        }
        if (getEffectiveFromDate() != null) {
            _hashCode += getEffectiveFromDate().hashCode();
        }
        if (getEffectiveToDate() != null) {
            _hashCode += getEffectiveToDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction_Response>DutyDefermentDisplay_Response>DGLDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteeCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>>ETMP_Transaction_Response>DutyDefermentDisplay_Response>DGLDetails>GuaranteeCategory"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteeInternalReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeInternalReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteeReferenceNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeReferenceNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteeAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guarantorID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuarantorID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveToDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
