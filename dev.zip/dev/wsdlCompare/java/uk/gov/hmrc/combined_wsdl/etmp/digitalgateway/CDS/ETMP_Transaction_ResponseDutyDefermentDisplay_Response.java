/**
 * ETMP_Transaction_ResponseDutyDefermentDisplay_Response.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_Transaction_ResponseDutyDefermentDisplay_Response  implements java.io.Serializable {
    private java.lang.String EORI;

    private java.lang.String DAN;

    private java.lang.String dutyDefermentAccountName;

    private java.util.Date DANStartDate;

    private java.util.Date DANEndDate;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails[] DGLDetails;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails[] DALDetails;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations;

    private boolean bankAssociatedIndicator;

    private java.lang.String interimPaymentRef;

    private java.lang.String CHAPSPaymentRef;

    public ETMP_Transaction_ResponseDutyDefermentDisplay_Response() {
    }

    public ETMP_Transaction_ResponseDutyDefermentDisplay_Response(
           java.lang.String EORI,
           java.lang.String DAN,
           java.lang.String dutyDefermentAccountName,
           java.util.Date DANStartDate,
           java.util.Date DANEndDate,
           uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails[] DGLDetails,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails[] DALDetails,
           uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses,
           uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations,
           boolean bankAssociatedIndicator,
           java.lang.String interimPaymentRef,
           java.lang.String CHAPSPaymentRef) {
           this.EORI = EORI;
           this.DAN = DAN;
           this.dutyDefermentAccountName = dutyDefermentAccountName;
           this.DANStartDate = DANStartDate;
           this.DANEndDate = DANEndDate;
           this.dutyDefermentStatus = dutyDefermentStatus;
           this.DGLDetails = DGLDetails;
           this.DALDetails = DALDetails;
           this.correspondenceAddresses = correspondenceAddresses;
           this.authorisations = authorisations;
           this.bankAssociatedIndicator = bankAssociatedIndicator;
           this.interimPaymentRef = interimPaymentRef;
           this.CHAPSPaymentRef = CHAPSPaymentRef;
    }


    /**
     * Gets the EORI value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return EORI
     */
    public java.lang.String getEORI() {
        return EORI;
    }


    /**
     * Sets the EORI value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param EORI
     */
    public void setEORI(java.lang.String EORI) {
        this.EORI = EORI;
    }


    /**
     * Gets the DAN value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return DAN
     */
    public java.lang.String getDAN() {
        return DAN;
    }


    /**
     * Sets the DAN value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param DAN
     */
    public void setDAN(java.lang.String DAN) {
        this.DAN = DAN;
    }


    /**
     * Gets the dutyDefermentAccountName value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return dutyDefermentAccountName
     */
    public java.lang.String getDutyDefermentAccountName() {
        return dutyDefermentAccountName;
    }


    /**
     * Sets the dutyDefermentAccountName value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param dutyDefermentAccountName
     */
    public void setDutyDefermentAccountName(java.lang.String dutyDefermentAccountName) {
        this.dutyDefermentAccountName = dutyDefermentAccountName;
    }


    /**
     * Gets the DANStartDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return DANStartDate
     */
    public java.util.Date getDANStartDate() {
        return DANStartDate;
    }


    /**
     * Sets the DANStartDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param DANStartDate
     */
    public void setDANStartDate(java.util.Date DANStartDate) {
        this.DANStartDate = DANStartDate;
    }


    /**
     * Gets the DANEndDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return DANEndDate
     */
    public java.util.Date getDANEndDate() {
        return DANEndDate;
    }


    /**
     * Sets the DANEndDate value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param DANEndDate
     */
    public void setDANEndDate(java.util.Date DANEndDate) {
        this.DANEndDate = DANEndDate;
    }


    /**
     * Gets the dutyDefermentStatus value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return dutyDefermentStatus
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType getDutyDefermentStatus() {
        return dutyDefermentStatus;
    }


    /**
     * Sets the dutyDefermentStatus value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param dutyDefermentStatus
     */
    public void setDutyDefermentStatus(uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusType dutyDefermentStatus) {
        this.dutyDefermentStatus = dutyDefermentStatus;
    }


    /**
     * Gets the DGLDetails value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return DGLDetails
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails[] getDGLDetails() {
        return DGLDetails;
    }


    /**
     * Sets the DGLDetails value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param DGLDetails
     */
    public void setDGLDetails(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails[] DGLDetails) {
        this.DGLDetails = DGLDetails;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails getDGLDetails(int i) {
        return this.DGLDetails[i];
    }

    public void setDGLDetails(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDGLDetails _value) {
        this.DGLDetails[i] = _value;
    }


    /**
     * Gets the DALDetails value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return DALDetails
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails[] getDALDetails() {
        return DALDetails;
    }


    /**
     * Sets the DALDetails value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param DALDetails
     */
    public void setDALDetails(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails[] DALDetails) {
        this.DALDetails = DALDetails;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails getDALDetails(int i) {
        return this.DALDetails[i];
    }

    public void setDALDetails(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_ResponseDALDetails _value) {
        this.DALDetails[i] = _value;
    }


    /**
     * Gets the correspondenceAddresses value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return correspondenceAddresses
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType getCorrespondenceAddresses() {
        return correspondenceAddresses;
    }


    /**
     * Sets the correspondenceAddresses value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param correspondenceAddresses
     */
    public void setCorrespondenceAddresses(uk.gov.hmrc.etmp.digitalgateway.CDS.AddressType correspondenceAddresses) {
        this.correspondenceAddresses = correspondenceAddresses;
    }


    /**
     * Gets the authorisations value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return authorisations
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] getAuthorisations() {
        return authorisations;
    }


    /**
     * Sets the authorisations value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param authorisations
     */
    public void setAuthorisations(uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations) {
        this.authorisations = authorisations;
    }

    public uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType getAuthorisations(int i) {
        return this.authorisations[i];
    }

    public void setAuthorisations(int i, uk.gov.hmrc.etmp.digitalgateway.CDS.AuthorisationsType _value) {
        this.authorisations[i] = _value;
    }


    /**
     * Gets the bankAssociatedIndicator value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return bankAssociatedIndicator
     */
    public boolean isBankAssociatedIndicator() {
        return bankAssociatedIndicator;
    }


    /**
     * Sets the bankAssociatedIndicator value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param bankAssociatedIndicator
     */
    public void setBankAssociatedIndicator(boolean bankAssociatedIndicator) {
        this.bankAssociatedIndicator = bankAssociatedIndicator;
    }


    /**
     * Gets the interimPaymentRef value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return interimPaymentRef
     */
    public java.lang.String getInterimPaymentRef() {
        return interimPaymentRef;
    }


    /**
     * Sets the interimPaymentRef value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param interimPaymentRef
     */
    public void setInterimPaymentRef(java.lang.String interimPaymentRef) {
        this.interimPaymentRef = interimPaymentRef;
    }


    /**
     * Gets the CHAPSPaymentRef value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @return CHAPSPaymentRef
     */
    public java.lang.String getCHAPSPaymentRef() {
        return CHAPSPaymentRef;
    }


    /**
     * Sets the CHAPSPaymentRef value for this ETMP_Transaction_ResponseDutyDefermentDisplay_Response.
     * 
     * @param CHAPSPaymentRef
     */
    public void setCHAPSPaymentRef(java.lang.String CHAPSPaymentRef) {
        this.CHAPSPaymentRef = CHAPSPaymentRef;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction_ResponseDutyDefermentDisplay_Response)) return false;
        ETMP_Transaction_ResponseDutyDefermentDisplay_Response other = (ETMP_Transaction_ResponseDutyDefermentDisplay_Response) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.EORI==null && other.getEORI()==null) || 
             (this.EORI!=null &&
              this.EORI.equals(other.getEORI()))) &&
            ((this.DAN==null && other.getDAN()==null) || 
             (this.DAN!=null &&
              this.DAN.equals(other.getDAN()))) &&
            ((this.dutyDefermentAccountName==null && other.getDutyDefermentAccountName()==null) || 
             (this.dutyDefermentAccountName!=null &&
              this.dutyDefermentAccountName.equals(other.getDutyDefermentAccountName()))) &&
            ((this.DANStartDate==null && other.getDANStartDate()==null) || 
             (this.DANStartDate!=null &&
              this.DANStartDate.equals(other.getDANStartDate()))) &&
            ((this.DANEndDate==null && other.getDANEndDate()==null) || 
             (this.DANEndDate!=null &&
              this.DANEndDate.equals(other.getDANEndDate()))) &&
            ((this.dutyDefermentStatus==null && other.getDutyDefermentStatus()==null) || 
             (this.dutyDefermentStatus!=null &&
              this.dutyDefermentStatus.equals(other.getDutyDefermentStatus()))) &&
            ((this.DGLDetails==null && other.getDGLDetails()==null) || 
             (this.DGLDetails!=null &&
              java.util.Arrays.equals(this.DGLDetails, other.getDGLDetails()))) &&
            ((this.DALDetails==null && other.getDALDetails()==null) || 
             (this.DALDetails!=null &&
              java.util.Arrays.equals(this.DALDetails, other.getDALDetails()))) &&
            ((this.correspondenceAddresses==null && other.getCorrespondenceAddresses()==null) || 
             (this.correspondenceAddresses!=null &&
              this.correspondenceAddresses.equals(other.getCorrespondenceAddresses()))) &&
            ((this.authorisations==null && other.getAuthorisations()==null) || 
             (this.authorisations!=null &&
              java.util.Arrays.equals(this.authorisations, other.getAuthorisations()))) &&
            this.bankAssociatedIndicator == other.isBankAssociatedIndicator() &&
            ((this.interimPaymentRef==null && other.getInterimPaymentRef()==null) || 
             (this.interimPaymentRef!=null &&
              this.interimPaymentRef.equals(other.getInterimPaymentRef()))) &&
            ((this.CHAPSPaymentRef==null && other.getCHAPSPaymentRef()==null) || 
             (this.CHAPSPaymentRef!=null &&
              this.CHAPSPaymentRef.equals(other.getCHAPSPaymentRef())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEORI() != null) {
            _hashCode += getEORI().hashCode();
        }
        if (getDAN() != null) {
            _hashCode += getDAN().hashCode();
        }
        if (getDutyDefermentAccountName() != null) {
            _hashCode += getDutyDefermentAccountName().hashCode();
        }
        if (getDANStartDate() != null) {
            _hashCode += getDANStartDate().hashCode();
        }
        if (getDANEndDate() != null) {
            _hashCode += getDANEndDate().hashCode();
        }
        if (getDutyDefermentStatus() != null) {
            _hashCode += getDutyDefermentStatus().hashCode();
        }
        if (getDGLDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDGLDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDGLDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDALDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDALDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDALDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCorrespondenceAddresses() != null) {
            _hashCode += getCorrespondenceAddresses().hashCode();
        }
        if (getAuthorisations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthorisations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthorisations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isBankAssociatedIndicator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getInterimPaymentRef() != null) {
            _hashCode += getInterimPaymentRef().hashCode();
        }
        if (getCHAPSPaymentRef() != null) {
            _hashCode += getCHAPSPaymentRef().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction_ResponseDutyDefermentDisplay_Response.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction_Response>DutyDefermentDisplay_Response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EORI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EORI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DAN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DAN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentAccountName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentAccountName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DANStartDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DANStartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DANEndDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DANEndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DGLDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DGLDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction_Response>DutyDefermentDisplay_Response>DGLDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DALDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DALDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction_Response>DutyDefermentDisplay_Response>DALDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondenceAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "CorrespondenceAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Authorisations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AuthorisationsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankAssociatedIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "BankAssociatedIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interimPaymentRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "InterimPaymentRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHAPSPaymentRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "CHAPSPaymentRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
