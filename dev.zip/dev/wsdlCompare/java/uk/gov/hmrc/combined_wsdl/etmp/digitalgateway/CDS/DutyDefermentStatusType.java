/**
 * DutyDefermentStatusType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class DutyDefermentStatusType  implements java.io.Serializable {
    /* 0 - Active
     * 1 - Change of legal entity
     * 2 - Guarantee cancelled - Guarantor's request
     * 3 - Guarantee cancelled - Trader's request
     * 4 - Direct Debit mandate cancelled
     * 5 - Debit rejected - Account closed or transferred
     * 6 - Debit rejected - Refer to drawer
     * 7 - Returned Mail/Other
     * 8 - Guarantee exceeded
     * 9 - Account cancelled */
    private uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusTypeStatus status;

    private java.util.Date effectiveDate;

    public DutyDefermentStatusType() {
    }

    public DutyDefermentStatusType(
           uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusTypeStatus status,
           java.util.Date effectiveDate) {
           this.status = status;
           this.effectiveDate = effectiveDate;
    }


    /**
     * Gets the status value for this DutyDefermentStatusType.
     * 
     * @return status   * 0 - Active
     * 1 - Change of legal entity
     * 2 - Guarantee cancelled - Guarantor's request
     * 3 - Guarantee cancelled - Trader's request
     * 4 - Direct Debit mandate cancelled
     * 5 - Debit rejected - Account closed or transferred
     * 6 - Debit rejected - Refer to drawer
     * 7 - Returned Mail/Other
     * 8 - Guarantee exceeded
     * 9 - Account cancelled
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusTypeStatus getStatus() {
        return status;
    }


    /**
     * Sets the status value for this DutyDefermentStatusType.
     * 
     * @param status   * 0 - Active
     * 1 - Change of legal entity
     * 2 - Guarantee cancelled - Guarantor's request
     * 3 - Guarantee cancelled - Trader's request
     * 4 - Direct Debit mandate cancelled
     * 5 - Debit rejected - Account closed or transferred
     * 6 - Debit rejected - Refer to drawer
     * 7 - Returned Mail/Other
     * 8 - Guarantee exceeded
     * 9 - Account cancelled
     */
    public void setStatus(uk.gov.hmrc.etmp.digitalgateway.CDS.DutyDefermentStatusTypeStatus status) {
        this.status = status;
    }


    /**
     * Gets the effectiveDate value for this DutyDefermentStatusType.
     * 
     * @return effectiveDate
     */
    public java.util.Date getEffectiveDate() {
        return effectiveDate;
    }


    /**
     * Sets the effectiveDate value for this DutyDefermentStatusType.
     * 
     * @param effectiveDate
     */
    public void setEffectiveDate(java.util.Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DutyDefermentStatusType)) return false;
        DutyDefermentStatusType other = (DutyDefermentStatusType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.effectiveDate==null && other.getEffectiveDate()==null) || 
             (this.effectiveDate!=null &&
              this.effectiveDate.equals(other.getEffectiveDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getEffectiveDate() != null) {
            _hashCode += getEffectiveDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DutyDefermentStatusType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentStatusType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">DutyDefermentStatusType>Status"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
