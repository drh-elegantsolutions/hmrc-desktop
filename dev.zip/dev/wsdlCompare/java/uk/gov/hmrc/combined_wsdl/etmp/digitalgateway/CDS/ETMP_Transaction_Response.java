/**
 * ETMP_Transaction_Response.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.etmp.digitalgateway.CDS;

public class ETMP_Transaction_Response  implements java.io.Serializable {
    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_Header ETMP_Transaction_Header;

    private uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_Response dutyDefermentDisplay_Response;

    public ETMP_Transaction_Response() {
    }

    public ETMP_Transaction_Response(
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_Header ETMP_Transaction_Header,
           uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_Response dutyDefermentDisplay_Response) {
           this.ETMP_Transaction_Header = ETMP_Transaction_Header;
           this.dutyDefermentDisplay_Response = dutyDefermentDisplay_Response;
    }


    /**
     * Gets the ETMP_Transaction_Header value for this ETMP_Transaction_Response.
     * 
     * @return ETMP_Transaction_Header
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_Header getETMP_Transaction_Header() {
        return ETMP_Transaction_Header;
    }


    /**
     * Sets the ETMP_Transaction_Header value for this ETMP_Transaction_Response.
     * 
     * @param ETMP_Transaction_Header
     */
    public void setETMP_Transaction_Header(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_Header ETMP_Transaction_Header) {
        this.ETMP_Transaction_Header = ETMP_Transaction_Header;
    }


    /**
     * Gets the dutyDefermentDisplay_Response value for this ETMP_Transaction_Response.
     * 
     * @return dutyDefermentDisplay_Response
     */
    public uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_Response getDutyDefermentDisplay_Response() {
        return dutyDefermentDisplay_Response;
    }


    /**
     * Sets the dutyDefermentDisplay_Response value for this ETMP_Transaction_Response.
     * 
     * @param dutyDefermentDisplay_Response
     */
    public void setDutyDefermentDisplay_Response(uk.gov.hmrc.etmp.digitalgateway.CDS.ETMP_Transaction_ResponseDutyDefermentDisplay_Response dutyDefermentDisplay_Response) {
        this.dutyDefermentDisplay_Response = dutyDefermentDisplay_Response;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction_Response)) return false;
        ETMP_Transaction_Response other = (ETMP_Transaction_Response) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ETMP_Transaction_Header==null && other.getETMP_Transaction_Header()==null) || 
             (this.ETMP_Transaction_Header!=null &&
              this.ETMP_Transaction_Header.equals(other.getETMP_Transaction_Header()))) &&
            ((this.dutyDefermentDisplay_Response==null && other.getDutyDefermentDisplay_Response()==null) || 
             (this.dutyDefermentDisplay_Response!=null &&
              this.dutyDefermentDisplay_Response.equals(other.getDutyDefermentDisplay_Response())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getETMP_Transaction_Header() != null) {
            _hashCode += getETMP_Transaction_Header().hashCode();
        }
        if (getDutyDefermentDisplay_Response() != null) {
            _hashCode += getDutyDefermentDisplay_Response().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction_Response.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction_Response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ETMP_Transaction_Header");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ETMP_Transaction_Header"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ETMP_ResponseTransaction_Header"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentDisplay_Response");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentDisplay_Response"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction_Response>DutyDefermentDisplay_Response"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
