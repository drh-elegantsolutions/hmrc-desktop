/**
 * ETMP_TransactionDutyDefermentDetailsBankDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS;

public class ETMP_TransactionDutyDefermentDetailsBankDetails  implements java.io.Serializable {
    private java.lang.String sortCode;

    private java.lang.String accountNumber;

    private java.lang.String accountHolderName;

    public ETMP_TransactionDutyDefermentDetailsBankDetails() {
    }

    public ETMP_TransactionDutyDefermentDetailsBankDetails(
           java.lang.String sortCode,
           java.lang.String accountNumber,
           java.lang.String accountHolderName) {
           this.sortCode = sortCode;
           this.accountNumber = accountNumber;
           this.accountHolderName = accountHolderName;
    }


    /**
     * Gets the sortCode value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @return sortCode
     */
    public java.lang.String getSortCode() {
        return sortCode;
    }


    /**
     * Sets the sortCode value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @param sortCode
     */
    public void setSortCode(java.lang.String sortCode) {
        this.sortCode = sortCode;
    }


    /**
     * Gets the accountNumber value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @return accountNumber
     */
    public java.lang.String getAccountNumber() {
        return accountNumber;
    }


    /**
     * Sets the accountNumber value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @param accountNumber
     */
    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }


    /**
     * Gets the accountHolderName value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @return accountHolderName
     */
    public java.lang.String getAccountHolderName() {
        return accountHolderName;
    }


    /**
     * Sets the accountHolderName value for this ETMP_TransactionDutyDefermentDetailsBankDetails.
     * 
     * @param accountHolderName
     */
    public void setAccountHolderName(java.lang.String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_TransactionDutyDefermentDetailsBankDetails)) return false;
        ETMP_TransactionDutyDefermentDetailsBankDetails other = (ETMP_TransactionDutyDefermentDetailsBankDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sortCode==null && other.getSortCode()==null) || 
             (this.sortCode!=null &&
              this.sortCode.equals(other.getSortCode()))) &&
            ((this.accountNumber==null && other.getAccountNumber()==null) || 
             (this.accountNumber!=null &&
              this.accountNumber.equals(other.getAccountNumber()))) &&
            ((this.accountHolderName==null && other.getAccountHolderName()==null) || 
             (this.accountHolderName!=null &&
              this.accountHolderName.equals(other.getAccountHolderName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSortCode() != null) {
            _hashCode += getSortCode().hashCode();
        }
        if (getAccountNumber() != null) {
            _hashCode += getAccountNumber().hashCode();
        }
        if (getAccountHolderName() != null) {
            _hashCode += getAccountHolderName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_TransactionDutyDefermentDetailsBankDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>BankDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "SortCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountHolderName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AccountHolderName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
