/**
 * ETMP_TransactionDutyDefermentDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS;

public class ETMP_TransactionDutyDefermentDetails  implements java.io.Serializable {
    private java.lang.String EORI;

    private java.lang.String dutyDefermentAccountName;

    private java.util.Date DANStartDate;

    private java.util.Date DANEndDate;

    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails;

    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType[] guarantees;

    private java.math.BigDecimal accountLimit;

    private boolean ioMApplication;

    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AddressType correspondenceAddresses;

    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations;

    public ETMP_TransactionDutyDefermentDetails() {
    }

    public ETMP_TransactionDutyDefermentDetails(
           java.lang.String EORI,
           java.lang.String dutyDefermentAccountName,
           java.util.Date DANStartDate,
           java.util.Date DANEndDate,
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails,
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType[] guarantees,
           java.math.BigDecimal accountLimit,
           boolean ioMApplication,
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AddressType correspondenceAddresses,
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations) {
           this.EORI = EORI;
           this.dutyDefermentAccountName = dutyDefermentAccountName;
           this.DANStartDate = DANStartDate;
           this.DANEndDate = DANEndDate;
           this.bankDetails = bankDetails;
           this.guarantees = guarantees;
           this.accountLimit = accountLimit;
           this.ioMApplication = ioMApplication;
           this.correspondenceAddresses = correspondenceAddresses;
           this.authorisations = authorisations;
    }


    /**
     * Gets the EORI value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return EORI
     */
    public java.lang.String getEORI() {
        return EORI;
    }


    /**
     * Sets the EORI value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param EORI
     */
    public void setEORI(java.lang.String EORI) {
        this.EORI = EORI;
    }


    /**
     * Gets the dutyDefermentAccountName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return dutyDefermentAccountName
     */
    public java.lang.String getDutyDefermentAccountName() {
        return dutyDefermentAccountName;
    }


    /**
     * Sets the dutyDefermentAccountName value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param dutyDefermentAccountName
     */
    public void setDutyDefermentAccountName(java.lang.String dutyDefermentAccountName) {
        this.dutyDefermentAccountName = dutyDefermentAccountName;
    }


    /**
     * Gets the DANStartDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return DANStartDate
     */
    public java.util.Date getDANStartDate() {
        return DANStartDate;
    }


    /**
     * Sets the DANStartDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param DANStartDate
     */
    public void setDANStartDate(java.util.Date DANStartDate) {
        this.DANStartDate = DANStartDate;
    }


    /**
     * Gets the DANEndDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return DANEndDate
     */
    public java.util.Date getDANEndDate() {
        return DANEndDate;
    }


    /**
     * Sets the DANEndDate value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param DANEndDate
     */
    public void setDANEndDate(java.util.Date DANEndDate) {
        this.DANEndDate = DANEndDate;
    }


    /**
     * Gets the bankDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return bankDetails
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails getBankDetails() {
        return bankDetails;
    }


    /**
     * Sets the bankDetails value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param bankDetails
     */
    public void setBankDetails(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_TransactionDutyDefermentDetailsBankDetails bankDetails) {
        this.bankDetails = bankDetails;
    }


    /**
     * Gets the guarantees value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return guarantees
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType[] getGuarantees() {
        return guarantees;
    }


    /**
     * Sets the guarantees value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param guarantees
     */
    public void setGuarantees(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType[] guarantees) {
        this.guarantees = guarantees;
    }

    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType getGuarantees(int i) {
        return this.guarantees[i];
    }

    public void setGuarantees(int i, uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.GuaranteeType _value) {
        this.guarantees[i] = _value;
    }


    /**
     * Gets the accountLimit value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return accountLimit
     */
    public java.math.BigDecimal getAccountLimit() {
        return accountLimit;
    }


    /**
     * Sets the accountLimit value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param accountLimit
     */
    public void setAccountLimit(java.math.BigDecimal accountLimit) {
        this.accountLimit = accountLimit;
    }


    /**
     * Gets the ioMApplication value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return ioMApplication
     */
    public boolean isIoMApplication() {
        return ioMApplication;
    }


    /**
     * Sets the ioMApplication value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param ioMApplication
     */
    public void setIoMApplication(boolean ioMApplication) {
        this.ioMApplication = ioMApplication;
    }


    /**
     * Gets the correspondenceAddresses value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return correspondenceAddresses
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AddressType getCorrespondenceAddresses() {
        return correspondenceAddresses;
    }


    /**
     * Sets the correspondenceAddresses value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param correspondenceAddresses
     */
    public void setCorrespondenceAddresses(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AddressType correspondenceAddresses) {
        this.correspondenceAddresses = correspondenceAddresses;
    }


    /**
     * Gets the authorisations value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @return authorisations
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType[] getAuthorisations() {
        return authorisations;
    }


    /**
     * Sets the authorisations value for this ETMP_TransactionDutyDefermentDetails.
     * 
     * @param authorisations
     */
    public void setAuthorisations(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType[] authorisations) {
        this.authorisations = authorisations;
    }

    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType getAuthorisations(int i) {
        return this.authorisations[i];
    }

    public void setAuthorisations(int i, uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.AuthorisationsType _value) {
        this.authorisations[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_TransactionDutyDefermentDetails)) return false;
        ETMP_TransactionDutyDefermentDetails other = (ETMP_TransactionDutyDefermentDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.EORI==null && other.getEORI()==null) || 
             (this.EORI!=null &&
              this.EORI.equals(other.getEORI()))) &&
            ((this.dutyDefermentAccountName==null && other.getDutyDefermentAccountName()==null) || 
             (this.dutyDefermentAccountName!=null &&
              this.dutyDefermentAccountName.equals(other.getDutyDefermentAccountName()))) &&
            ((this.DANStartDate==null && other.getDANStartDate()==null) || 
             (this.DANStartDate!=null &&
              this.DANStartDate.equals(other.getDANStartDate()))) &&
            ((this.DANEndDate==null && other.getDANEndDate()==null) || 
             (this.DANEndDate!=null &&
              this.DANEndDate.equals(other.getDANEndDate()))) &&
            ((this.bankDetails==null && other.getBankDetails()==null) || 
             (this.bankDetails!=null &&
              this.bankDetails.equals(other.getBankDetails()))) &&
            ((this.guarantees==null && other.getGuarantees()==null) || 
             (this.guarantees!=null &&
              java.util.Arrays.equals(this.guarantees, other.getGuarantees()))) &&
            ((this.accountLimit==null && other.getAccountLimit()==null) || 
             (this.accountLimit!=null &&
              this.accountLimit.equals(other.getAccountLimit()))) &&
            this.ioMApplication == other.isIoMApplication() &&
            ((this.correspondenceAddresses==null && other.getCorrespondenceAddresses()==null) || 
             (this.correspondenceAddresses!=null &&
              this.correspondenceAddresses.equals(other.getCorrespondenceAddresses()))) &&
            ((this.authorisations==null && other.getAuthorisations()==null) || 
             (this.authorisations!=null &&
              java.util.Arrays.equals(this.authorisations, other.getAuthorisations())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEORI() != null) {
            _hashCode += getEORI().hashCode();
        }
        if (getDutyDefermentAccountName() != null) {
            _hashCode += getDutyDefermentAccountName().hashCode();
        }
        if (getDANStartDate() != null) {
            _hashCode += getDANStartDate().hashCode();
        }
        if (getDANEndDate() != null) {
            _hashCode += getDANEndDate().hashCode();
        }
        if (getBankDetails() != null) {
            _hashCode += getBankDetails().hashCode();
        }
        if (getGuarantees() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGuarantees());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGuarantees(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAccountLimit() != null) {
            _hashCode += getAccountLimit().hashCode();
        }
        _hashCode += (isIoMApplication() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCorrespondenceAddresses() != null) {
            _hashCode += getCorrespondenceAddresses().hashCode();
        }
        if (getAuthorisations() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthorisations());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthorisations(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_TransactionDutyDefermentDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_Transaction>DutyDefermentDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EORI");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EORI"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dutyDefermentAccountName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DutyDefermentAccountName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DANStartDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DANStartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DANEndDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "DANEndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "BankDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>>ETMP_Transaction>DutyDefermentDetails>BankDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guarantees");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Guarantees"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AccountLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ioMApplication");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "IoMApplication"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondenceAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "CorrespondenceAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AddressType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Authorisations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AuthorisationsType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
