/**
 * ETMP_Transaction_Resp_Header.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS;

public class ETMP_Transaction_Resp_Header  implements java.io.Serializable {
    /* Possible values are 
     *      OK                                    NOT_OK */
    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderStatus status;

    /* Status Text */
    private java.lang.String statusText;

    /* The date the message was processed */
    private java.util.Calendar processingDate;

    /* Return Parameters */
    private uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters[] returnParameters;

    private java.lang.String interimPaymentRef;

    private java.lang.String CHAPSPaymentRef;

    public ETMP_Transaction_Resp_Header() {
    }

    public ETMP_Transaction_Resp_Header(
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderStatus status,
           java.lang.String statusText,
           java.util.Calendar processingDate,
           uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters[] returnParameters,
           java.lang.String interimPaymentRef,
           java.lang.String CHAPSPaymentRef) {
           this.status = status;
           this.statusText = statusText;
           this.processingDate = processingDate;
           this.returnParameters = returnParameters;
           this.interimPaymentRef = interimPaymentRef;
           this.CHAPSPaymentRef = CHAPSPaymentRef;
    }


    /**
     * Gets the status value for this ETMP_Transaction_Resp_Header.
     * 
     * @return status   * Possible values are 
     *      OK                                    NOT_OK
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderStatus getStatus() {
        return status;
    }


    /**
     * Sets the status value for this ETMP_Transaction_Resp_Header.
     * 
     * @param status   * Possible values are 
     *      OK                                    NOT_OK
     */
    public void setStatus(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderStatus status) {
        this.status = status;
    }


    /**
     * Gets the statusText value for this ETMP_Transaction_Resp_Header.
     * 
     * @return statusText   * Status Text
     */
    public java.lang.String getStatusText() {
        return statusText;
    }


    /**
     * Sets the statusText value for this ETMP_Transaction_Resp_Header.
     * 
     * @param statusText   * Status Text
     */
    public void setStatusText(java.lang.String statusText) {
        this.statusText = statusText;
    }


    /**
     * Gets the processingDate value for this ETMP_Transaction_Resp_Header.
     * 
     * @return processingDate   * The date the message was processed
     */
    public java.util.Calendar getProcessingDate() {
        return processingDate;
    }


    /**
     * Sets the processingDate value for this ETMP_Transaction_Resp_Header.
     * 
     * @param processingDate   * The date the message was processed
     */
    public void setProcessingDate(java.util.Calendar processingDate) {
        this.processingDate = processingDate;
    }


    /**
     * Gets the returnParameters value for this ETMP_Transaction_Resp_Header.
     * 
     * @return returnParameters   * Return Parameters
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters[] getReturnParameters() {
        return returnParameters;
    }


    /**
     * Sets the returnParameters value for this ETMP_Transaction_Resp_Header.
     * 
     * @param returnParameters   * Return Parameters
     */
    public void setReturnParameters(uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters[] returnParameters) {
        this.returnParameters = returnParameters;
    }

    public uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters getReturnParameters(int i) {
        return this.returnParameters[i];
    }

    public void setReturnParameters(int i, uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Resp_HeaderReturnParameters _value) {
        this.returnParameters[i] = _value;
    }


    /**
     * Gets the interimPaymentRef value for this ETMP_Transaction_Resp_Header.
     * 
     * @return interimPaymentRef
     */
    public java.lang.String getInterimPaymentRef() {
        return interimPaymentRef;
    }


    /**
     * Sets the interimPaymentRef value for this ETMP_Transaction_Resp_Header.
     * 
     * @param interimPaymentRef
     */
    public void setInterimPaymentRef(java.lang.String interimPaymentRef) {
        this.interimPaymentRef = interimPaymentRef;
    }


    /**
     * Gets the CHAPSPaymentRef value for this ETMP_Transaction_Resp_Header.
     * 
     * @return CHAPSPaymentRef
     */
    public java.lang.String getCHAPSPaymentRef() {
        return CHAPSPaymentRef;
    }


    /**
     * Sets the CHAPSPaymentRef value for this ETMP_Transaction_Resp_Header.
     * 
     * @param CHAPSPaymentRef
     */
    public void setCHAPSPaymentRef(java.lang.String CHAPSPaymentRef) {
        this.CHAPSPaymentRef = CHAPSPaymentRef;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_Transaction_Resp_Header)) return false;
        ETMP_Transaction_Resp_Header other = (ETMP_Transaction_Resp_Header) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.statusText==null && other.getStatusText()==null) || 
             (this.statusText!=null &&
              this.statusText.equals(other.getStatusText()))) &&
            ((this.processingDate==null && other.getProcessingDate()==null) || 
             (this.processingDate!=null &&
              this.processingDate.equals(other.getProcessingDate()))) &&
            ((this.returnParameters==null && other.getReturnParameters()==null) || 
             (this.returnParameters!=null &&
              java.util.Arrays.equals(this.returnParameters, other.getReturnParameters()))) &&
            ((this.interimPaymentRef==null && other.getInterimPaymentRef()==null) || 
             (this.interimPaymentRef!=null &&
              this.interimPaymentRef.equals(other.getInterimPaymentRef()))) &&
            ((this.CHAPSPaymentRef==null && other.getCHAPSPaymentRef()==null) || 
             (this.CHAPSPaymentRef!=null &&
              this.CHAPSPaymentRef.equals(other.getCHAPSPaymentRef())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getStatusText() != null) {
            _hashCode += getStatusText().hashCode();
        }
        if (getProcessingDate() != null) {
            _hashCode += getProcessingDate().hashCode();
        }
        if (getReturnParameters() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getReturnParameters());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getReturnParameters(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInterimPaymentRef() != null) {
            _hashCode += getInterimPaymentRef().hashCode();
        }
        if (getCHAPSPaymentRef() != null) {
            _hashCode += getCHAPSPaymentRef().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_Transaction_Resp_Header.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ETMP_Transaction_Resp_Header"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction_Resp_Header>Status"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "StatusText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processingDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ProcessingDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ReturnParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_Transaction_Resp_Header>ReturnParameters"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interimPaymentRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "InterimPaymentRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHAPSPaymentRef");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "CHAPSPaymentRef"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
