/**
 * DutyDefermentDisplaySync.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS;

public interface DutyDefermentDisplaySync extends java.rmi.Remote {
    public uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_Transaction_Response dutyDefermentDisplaySync(uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_Transaction ETMP_Transaction) throws java.rmi.RemoteException, uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.StandardMessageFault;
}
