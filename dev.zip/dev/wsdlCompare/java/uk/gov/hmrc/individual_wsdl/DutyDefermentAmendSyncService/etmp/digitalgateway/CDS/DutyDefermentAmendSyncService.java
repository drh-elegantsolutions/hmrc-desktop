/**
 * DutyDefermentAmendSyncService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS;

public interface DutyDefermentAmendSyncService extends javax.xml.rpc.Service {
    public java.lang.String getHTTPS_PortAddress();

    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync getHTTPS_Port() throws javax.xml.rpc.ServiceException;

    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync getHTTPS_Port(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getHTTP_PortAddress();

    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync getHTTP_Port() throws javax.xml.rpc.ServiceException;

    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync getHTTP_Port(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
