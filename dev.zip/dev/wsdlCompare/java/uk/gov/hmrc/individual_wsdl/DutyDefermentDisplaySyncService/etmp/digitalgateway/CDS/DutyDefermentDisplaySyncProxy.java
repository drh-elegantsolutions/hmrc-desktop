package uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS;

public class DutyDefermentDisplaySyncProxy implements uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.DutyDefermentDisplaySync {
  private String _endpoint = null;
  private uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.DutyDefermentDisplaySync dutyDefermentDisplaySync = null;
  
  public DutyDefermentDisplaySyncProxy() {
    _initDutyDefermentDisplaySyncProxy();
  }
  
  public DutyDefermentDisplaySyncProxy(String endpoint) {
    _endpoint = endpoint;
    _initDutyDefermentDisplaySyncProxy();
  }
  
  private void _initDutyDefermentDisplaySyncProxy() {
    try {
      dutyDefermentDisplaySync = (new uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.DutyDefermentDisplaySyncServiceLocator()).getHTTPS_Port();
      if (dutyDefermentDisplaySync != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dutyDefermentDisplaySync != null)
      ((javax.xml.rpc.Stub)dutyDefermentDisplaySync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.DutyDefermentDisplaySync getDutyDefermentDisplaySync() {
    if (dutyDefermentDisplaySync == null)
      _initDutyDefermentDisplaySyncProxy();
    return dutyDefermentDisplaySync;
  }
  
  
}