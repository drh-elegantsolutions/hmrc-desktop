/**
 * GuaranteeType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentApplicationSyncService.etmp.digitalgateway.CDS;

public class GuaranteeType  implements java.io.Serializable {
    private java.lang.String guarantorID;

    private java.math.BigDecimal permanentGuaranteeAmount;

    private java.lang.String guaranteeReferenceNumber;

    public GuaranteeType() {
    }

    public GuaranteeType(
           java.lang.String guarantorID,
           java.math.BigDecimal permanentGuaranteeAmount,
           java.lang.String guaranteeReferenceNumber) {
           this.guarantorID = guarantorID;
           this.permanentGuaranteeAmount = permanentGuaranteeAmount;
           this.guaranteeReferenceNumber = guaranteeReferenceNumber;
    }


    /**
     * Gets the guarantorID value for this GuaranteeType.
     * 
     * @return guarantorID
     */
    public java.lang.String getGuarantorID() {
        return guarantorID;
    }


    /**
     * Sets the guarantorID value for this GuaranteeType.
     * 
     * @param guarantorID
     */
    public void setGuarantorID(java.lang.String guarantorID) {
        this.guarantorID = guarantorID;
    }


    /**
     * Gets the permanentGuaranteeAmount value for this GuaranteeType.
     * 
     * @return permanentGuaranteeAmount
     */
    public java.math.BigDecimal getPermanentGuaranteeAmount() {
        return permanentGuaranteeAmount;
    }


    /**
     * Sets the permanentGuaranteeAmount value for this GuaranteeType.
     * 
     * @param permanentGuaranteeAmount
     */
    public void setPermanentGuaranteeAmount(java.math.BigDecimal permanentGuaranteeAmount) {
        this.permanentGuaranteeAmount = permanentGuaranteeAmount;
    }


    /**
     * Gets the guaranteeReferenceNumber value for this GuaranteeType.
     * 
     * @return guaranteeReferenceNumber
     */
    public java.lang.String getGuaranteeReferenceNumber() {
        return guaranteeReferenceNumber;
    }


    /**
     * Sets the guaranteeReferenceNumber value for this GuaranteeType.
     * 
     * @param guaranteeReferenceNumber
     */
    public void setGuaranteeReferenceNumber(java.lang.String guaranteeReferenceNumber) {
        this.guaranteeReferenceNumber = guaranteeReferenceNumber;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GuaranteeType)) return false;
        GuaranteeType other = (GuaranteeType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.guarantorID==null && other.getGuarantorID()==null) || 
             (this.guarantorID!=null &&
              this.guarantorID.equals(other.getGuarantorID()))) &&
            ((this.permanentGuaranteeAmount==null && other.getPermanentGuaranteeAmount()==null) || 
             (this.permanentGuaranteeAmount!=null &&
              this.permanentGuaranteeAmount.equals(other.getPermanentGuaranteeAmount()))) &&
            ((this.guaranteeReferenceNumber==null && other.getGuaranteeReferenceNumber()==null) || 
             (this.guaranteeReferenceNumber!=null &&
              this.guaranteeReferenceNumber.equals(other.getGuaranteeReferenceNumber())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGuarantorID() != null) {
            _hashCode += getGuarantorID().hashCode();
        }
        if (getPermanentGuaranteeAmount() != null) {
            _hashCode += getPermanentGuaranteeAmount().hashCode();
        }
        if (getGuaranteeReferenceNumber() != null) {
            _hashCode += getGuaranteeReferenceNumber().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GuaranteeType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guarantorID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuarantorID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("permanentGuaranteeAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "PermanentGuaranteeAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteeReferenceNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "GuaranteeReferenceNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
