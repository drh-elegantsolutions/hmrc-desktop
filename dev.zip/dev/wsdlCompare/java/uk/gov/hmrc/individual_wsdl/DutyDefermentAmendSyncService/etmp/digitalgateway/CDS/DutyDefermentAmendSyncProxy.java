package uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS;

public class DutyDefermentAmendSyncProxy implements uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync {
  private String _endpoint = null;
  private uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync dutyDefermentAmendSync = null;
  
  public DutyDefermentAmendSyncProxy() {
    _initDutyDefermentAmendSyncProxy();
  }
  
  public DutyDefermentAmendSyncProxy(String endpoint) {
    _endpoint = endpoint;
    _initDutyDefermentAmendSyncProxy();
  }
  
  private void _initDutyDefermentAmendSyncProxy() {
    try {
      dutyDefermentAmendSync = (new uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSyncServiceLocator()).getHTTPS_Port();
      if (dutyDefermentAmendSync != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dutyDefermentAmendSync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dutyDefermentAmendSync)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dutyDefermentAmendSync != null)
      ((javax.xml.rpc.Stub)dutyDefermentAmendSync)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.DutyDefermentAmendSync getDutyDefermentAmendSync() {
    if (dutyDefermentAmendSync == null)
      _initDutyDefermentAmendSyncProxy();
    return dutyDefermentAmendSync;
  }
  
  
}