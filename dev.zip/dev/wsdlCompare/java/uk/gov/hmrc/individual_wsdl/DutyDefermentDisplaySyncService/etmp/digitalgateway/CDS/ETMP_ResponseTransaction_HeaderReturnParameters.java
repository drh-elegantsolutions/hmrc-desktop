/**
 * ETMP_ResponseTransaction_HeaderReturnParameters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS;

public class ETMP_ResponseTransaction_HeaderReturnParameters  implements java.io.Serializable {
    /* Parameter Name. Possible values are:     ERRORCODE      ERRORTEXT */
    private uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParametersParamName paramName;

    /* Parameter Value */
    private java.lang.String paramValue;

    public ETMP_ResponseTransaction_HeaderReturnParameters() {
    }

    public ETMP_ResponseTransaction_HeaderReturnParameters(
           uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParametersParamName paramName,
           java.lang.String paramValue) {
           this.paramName = paramName;
           this.paramValue = paramValue;
    }


    /**
     * Gets the paramName value for this ETMP_ResponseTransaction_HeaderReturnParameters.
     * 
     * @return paramName   * Parameter Name. Possible values are:     ERRORCODE      ERRORTEXT
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParametersParamName getParamName() {
        return paramName;
    }


    /**
     * Sets the paramName value for this ETMP_ResponseTransaction_HeaderReturnParameters.
     * 
     * @param paramName   * Parameter Name. Possible values are:     ERRORCODE      ERRORTEXT
     */
    public void setParamName(uk.gov.hmrc.individual-wsdl.DutyDefermentDisplaySyncService.etmp.digitalgateway.CDS.ETMP_ResponseTransaction_HeaderReturnParametersParamName paramName) {
        this.paramName = paramName;
    }


    /**
     * Gets the paramValue value for this ETMP_ResponseTransaction_HeaderReturnParameters.
     * 
     * @return paramValue   * Parameter Value
     */
    public java.lang.String getParamValue() {
        return paramValue;
    }


    /**
     * Sets the paramValue value for this ETMP_ResponseTransaction_HeaderReturnParameters.
     * 
     * @param paramValue   * Parameter Value
     */
    public void setParamValue(java.lang.String paramValue) {
        this.paramValue = paramValue;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ETMP_ResponseTransaction_HeaderReturnParameters)) return false;
        ETMP_ResponseTransaction_HeaderReturnParameters other = (ETMP_ResponseTransaction_HeaderReturnParameters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.paramName==null && other.getParamName()==null) || 
             (this.paramName!=null &&
              this.paramName.equals(other.getParamName()))) &&
            ((this.paramValue==null && other.getParamValue()==null) || 
             (this.paramValue!=null &&
              this.paramValue.equals(other.getParamValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getParamName() != null) {
            _hashCode += getParamName().hashCode();
        }
        if (getParamValue() != null) {
            _hashCode += getParamValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ETMP_ResponseTransaction_HeaderReturnParameters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">ETMP_ResponseTransaction_Header>ReturnParameters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ParamName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">>ETMP_ResponseTransaction_Header>ReturnParameters>ParamName"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paramValue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "ParamValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
