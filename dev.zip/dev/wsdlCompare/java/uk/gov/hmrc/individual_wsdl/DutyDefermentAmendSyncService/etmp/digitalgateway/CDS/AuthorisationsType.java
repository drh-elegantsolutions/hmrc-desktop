/**
 * AuthorisationsType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS;

public class AuthorisationsType  implements java.io.Serializable {
    /* AEO
     * EPSS
     * SIVA */
    private uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeAuthorisationType authorisationType;

    /* 0 - Active
     * 1 - Inactive */
    private uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeStatus status;

    private java.util.Date effectiveFromDate;

    private java.util.Date effectiveToDate;

    private org.apache.axis.types.NonNegativeInteger percentage;

    public AuthorisationsType() {
    }

    public AuthorisationsType(
           uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeAuthorisationType authorisationType,
           uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeStatus status,
           java.util.Date effectiveFromDate,
           java.util.Date effectiveToDate,
           org.apache.axis.types.NonNegativeInteger percentage) {
           this.authorisationType = authorisationType;
           this.status = status;
           this.effectiveFromDate = effectiveFromDate;
           this.effectiveToDate = effectiveToDate;
           this.percentage = percentage;
    }


    /**
     * Gets the authorisationType value for this AuthorisationsType.
     * 
     * @return authorisationType   * AEO
     * EPSS
     * SIVA
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeAuthorisationType getAuthorisationType() {
        return authorisationType;
    }


    /**
     * Sets the authorisationType value for this AuthorisationsType.
     * 
     * @param authorisationType   * AEO
     * EPSS
     * SIVA
     */
    public void setAuthorisationType(uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeAuthorisationType authorisationType) {
        this.authorisationType = authorisationType;
    }


    /**
     * Gets the status value for this AuthorisationsType.
     * 
     * @return status   * 0 - Active
     * 1 - Inactive
     */
    public uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeStatus getStatus() {
        return status;
    }


    /**
     * Sets the status value for this AuthorisationsType.
     * 
     * @param status   * 0 - Active
     * 1 - Inactive
     */
    public void setStatus(uk.gov.hmrc.individual-wsdl.DutyDefermentAmendSyncService.etmp.digitalgateway.CDS.AuthorisationsTypeStatus status) {
        this.status = status;
    }


    /**
     * Gets the effectiveFromDate value for this AuthorisationsType.
     * 
     * @return effectiveFromDate
     */
    public java.util.Date getEffectiveFromDate() {
        return effectiveFromDate;
    }


    /**
     * Sets the effectiveFromDate value for this AuthorisationsType.
     * 
     * @param effectiveFromDate
     */
    public void setEffectiveFromDate(java.util.Date effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }


    /**
     * Gets the effectiveToDate value for this AuthorisationsType.
     * 
     * @return effectiveToDate
     */
    public java.util.Date getEffectiveToDate() {
        return effectiveToDate;
    }


    /**
     * Sets the effectiveToDate value for this AuthorisationsType.
     * 
     * @param effectiveToDate
     */
    public void setEffectiveToDate(java.util.Date effectiveToDate) {
        this.effectiveToDate = effectiveToDate;
    }


    /**
     * Gets the percentage value for this AuthorisationsType.
     * 
     * @return percentage
     */
    public org.apache.axis.types.NonNegativeInteger getPercentage() {
        return percentage;
    }


    /**
     * Sets the percentage value for this AuthorisationsType.
     * 
     * @param percentage
     */
    public void setPercentage(org.apache.axis.types.NonNegativeInteger percentage) {
        this.percentage = percentage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthorisationsType)) return false;
        AuthorisationsType other = (AuthorisationsType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authorisationType==null && other.getAuthorisationType()==null) || 
             (this.authorisationType!=null &&
              this.authorisationType.equals(other.getAuthorisationType()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.effectiveFromDate==null && other.getEffectiveFromDate()==null) || 
             (this.effectiveFromDate!=null &&
              this.effectiveFromDate.equals(other.getEffectiveFromDate()))) &&
            ((this.effectiveToDate==null && other.getEffectiveToDate()==null) || 
             (this.effectiveToDate!=null &&
              this.effectiveToDate.equals(other.getEffectiveToDate()))) &&
            ((this.percentage==null && other.getPercentage()==null) || 
             (this.percentage!=null &&
              this.percentage.equals(other.getPercentage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthorisationType() != null) {
            _hashCode += getAuthorisationType().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getEffectiveFromDate() != null) {
            _hashCode += getEffectiveFromDate().hashCode();
        }
        if (getEffectiveToDate() != null) {
            _hashCode += getEffectiveToDate().hashCode();
        }
        if (getPercentage() != null) {
            _hashCode += getPercentage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthorisationsType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AuthorisationsType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorisationType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "AuthorisationType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">AuthorisationsType>AuthorisationType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", ">AuthorisationsType>Status"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveToDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "EffectiveToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://hmrc.gov.uk/etmp/digitalgateway/CDS", "Percentage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "nonNegativeInteger"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
